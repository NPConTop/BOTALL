const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const bamlol = fs.readFileSync('./assets/images/thumb.jpeg');
const path = require("path");
const token = config.BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });
const sessions = new Map();
const readline = require('readline');
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let premiumUsers = JSON.parse(fs.readFileSync('./premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./admin.json'));

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./premium.json');
ensureFileExists('./admin.json');

// Fungsi untuk menyimpan data premium dan admin
function savePremiumUsers() {
    fs.writeFileSync('./premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./admin.json', JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./premium.json', (data) => (premiumUsers = data));
watchFile('./admin.json', (data) => (adminUsers = data));


function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

const BOT_TOKEN = config.BOT_TOKEN;
const GITHUB_TOKEN_LIST_URL =
  "https://raw.githubusercontent.com/NPConTop/BOTALL/refs/heads/main/databasebot.json";
async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(
      chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message)
    );
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("Memeriksa Token Anda 🔎"));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("Token Tidak Terdaftar Di Database❌...."));
    process.exit(1);
  }

  console.log(chalk.green(` Token Terdaftar Di Database✅...⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(
    chalk.red(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣷⠀⠀⢠⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣰⣿⣿⣿⣿⣿⡇⠀⣸⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⡇⠀⢿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀
⠀⣠⣶⣦⡀⠹⣿⣿⣿⣿⡿⠁⠀⠘⣿⣿⣿⣿⣿⠇⣠⣴⣶⡄⠀
⢰⣿⣿⣿⣿⣆⠉⠛⠛⠋⠁⣀⣀⣀⠈⠛⠛⠛⠁⣼⣿⣿⣿⣿⡀
⢸⣿⣿⣿⣿⣿⡆⠀⢀⣴⣿⣿⣿⣿⣿⣦⠀⠀⢸⣿⣿⣿⣿⣿⡇
⠈⢿⣿⣿⣿⣿⠃⣠⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⢸⣿⣿⣿⣿⠟⠀
⠀⠀⠉⠙⠋⣡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣍⠛⠋⠁⠀⠀
⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀
⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀
⠀⠀⠀⠀⠈⠻⢿⣿⣿⣿⣿⡿⠿⢿⣿⣿⣿⣿⡿⠛⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀ 

𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍 𝐂𝐑𝐀𝐒𝐇\`
𝐒𝐂𝐑𝐈𝐏𝐓 𝐁𝐘 𝐕𝐈𝐗𝐙𝐙
=========================================
`)
  );

  console.log(
    chalk.red(`
𝐖𝐄𝐋𝐋𝐂𝐎𝐌𝐄 𝐌𝐘 𝐁𝐔𝐘𝐄𝐑 👋
`)
  );

  console.log(
    chalk.red(`
𝐁𝐎𝐓 𝐈𝐒 𝐑𝐔𝐍𝐈𝐍𝐆
`)
  );
}


let sock;

// Pastikan file 

async function connectToWhatsApp(botNumber, chatId, mode = "pairing") {
  // mode: "pairing" atau "qr"

  const statusMessage = await bot.sendMessage(
    chatId,
    `📋 𝐒𝐓𝐀𝐓𝐔𝐒 𝐂𝐎𝐍𝐍𝐄𝐂𝐓  
✦ 𝐍𝐎𝐌𝐎𝐑  : 「 ${botNumber} 」
└ 𝐌𝐎𝐃𝐄 : ${mode === "pairing" ? "PAIRING CODE" : "QR CODE"}
└ 𝐒𝐓𝐀𝐓𝐔𝐒 : Connecting...`,
    { parse_mode: "Markdown" }
  ).then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: mode === "qr", // QR code di terminal kalau mode === "qr"
    logger: P({ level: "silent" }),
  });

  let pairingRequested = false;

  sock.ev.on("connection.update", async (update) => {
  const { connection, lastDisconnect, qr } = update;

  if (connection === "connecting" && !pairingRequested) {
    pairingRequested = true;

    if (mode === "pairing") {
      try {
        const code = await sock.requestPairingCode(botNumber);
        const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

        await bot.editMessageText(
          `📋 𝐏𝐀𝐈𝐑𝐈𝐍𝐆 𝐂𝐎𝐃𝐄\n✦ NOMOR: ${botNumber}\n└ KODE: *${formattedCode}*`,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );
      } catch (err) {
        console.error("Error requestPairingCode:", err);

        await bot.editMessageText(
          `❌ Gagal pairing: ${err.message}`,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );

        // Force END & return biar ga loop
        sock.end(new Error("Force close after pairing fail"));
        return;
      }
    } else if (mode === "qr" && qr) {
      await bot.editMessageText(
        `📋 𝐐𝐑 𝐌𝐎𝐃𝐄\n✦ NOMOR: ${botNumber}\n└ QR code muncul di terminal`,
        { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
      );
    }
  }

  if (connection === "open") {
    sessions.set(botNumber, sock);
    saveActiveSessions(botNumber);
    await bot.editMessageText(
      `✅ *BERHASIL TERSAMBUNG*\n✦ Nomor: ${botNumber}`,
      { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
    );
  }

  if (connection === "close") {
    const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;

    if (shouldReconnect && mode === "qr") {
      // Boleh retry kalau QR
      await bot.editMessageText(`⚠️ Koneksi putus. Mencoba ulang...`,
        { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" });
      connectToWhatsApp(botNumber, chatId, mode);
    } else {
      await bot.editMessageText(`❌ Koneksi ditutup permanen.`,
        { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" });

      try {
        fs.rmSync(sessionDir, { recursive: true, force: true });
      } catch (err) {
        console.error("Error deleting session:", err);
      }
    }
  }
});

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

async function initializeWhatsAppConnections(mode = "pairing") {
  try {
    if (!fs.existsSync(SESSIONS_FILE)) {
      console.log("❌ Tidak ada file active_sessions.json, belum ada sesi tersimpan.");
      return;
    }

    const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
    if (!Array.isArray(activeNumbers) || activeNumbers.length === 0) {
      console.log("❌ Tidak ada nomor aktif di active_sessions.json");
      return;
    }

    console.log(`🔍 Menemukan ${activeNumbers.length} sesi aktif`);
    console.log(`Mode koneksi: ${mode}`);

    for (const botNumber of activeNumbers) {
      console.log(`⏳ Menghubungkan nomor: ${botNumber}`);
      // Ganti dengan ID Telegram kamu, misalnya OWNER_ID
      await connectToWhatsApp(botNumber, OWNER_ID, mode);
    }

  } catch (error) {
    console.error("❌ Gagal initializeWhatsAppConnections:", error);
  }
}

// [ BUG FUNCTION ]



// bagian ini buat cek owner user, gausah di hapus 
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


const bugRequests = {};

function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  return `${days}𝗗, ${hours}𝗛, ${minutes}𝗠, ${seconds}𝗦`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~Get Speed Bots🔧🗑️
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); 
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(user => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return "✔";
  } else {
    return "✘";
  }
}

const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "✇";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✇";
        return true;
    } else {
        Premiumataubukan = "Ӝ";
        return false;
    }
};

const checkPremium = async (ctx, next) => {
    if (isPremiumUser(ctx.from.id)) {
        await next();
    } else {
        await ctx.reply("❌ bukan owner");
    }
};
// Handler untuk /start
bot.onText(/\/ror/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();
  
  bot.sendVideo(chatId, "https://files.catbox.moe/m9ex04.mp4", { 
    caption: `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢
🜲 𝚃𝚒𝚖𝚎: ${runtime}
         ☄︎ 𝙿𝚎𝚗𝚐𝚐𝚞𝚗𝚊 ☄︎
🜲 𝚂𝚝𝚊𝚝𝚞𝚜: ${premiumStatus}
🜲 𝙽𝚊𝚖𝚎: ${username}
🜲 𝙸𝚍𝚃𝚎𝚕𝚎: ${senderId}

( ☬ ) ༑𝐏͢𝐫͡𝐞𝐬͜𝐬͡⍣᳟𝐁͡𝐮͢͡𝐭𝐭͢𝐨͜n͡⍣᳟M͡𝐞͡𝐧͢𝐮͜꙳⟅`,
    reply_markup: {
      inline_keyboard: [
        [{ text: "☣︎︎︎", callback_data: "bugmenu" }, { text: "🜲", callback_data: "ownermenu" }],
        [{ text: "☯", callback_data: "thanksto" }, {text: "✰", callback_data: "controlmenu" }]
      ]
    }
  });
});



bot.on("callback_query", (query) => {
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const data = query.data;
  const senderId = query.from.id;
  
  if (data === "bugmenu") {
         if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    return bot.sendMessage(chatId, "❌ You are not a premium user or your subscription has expired.");   
  }
  
    bot.sendVideo(chatId, "https://files.catbox.moe/gcouxh.mp4", {
    caption: `
╭━━━━[ 𝘌𝘯𝘵𝘦𝘳 𝘕𝘶𝘮𝘣𝘦𝘳 𝘛𝘢𝘳𝘨𝘦𝘵 ]
┃ 𝙲𝙾𝙽𝚃𝙾𝙷 : 62xxxx
╰━━━━━━━━━━━━━━━━━━━━━━
`,
    parse_mode: "Markdown",
    reply_markup: {
        inline_keyboard: [
            [{ text: "📞 𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/NPCmodeSad" }],
            [{ text: "📌 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯", url: "https://t.me/" }]
        ]
    }
});

bugRequests[chatId] = { stage: "awaitingNumber" }; 
  } else if (data === "ownermenu") {
    bot.sendVideo(chatId, "https://files.catbox.moe/m9ex04.mp4", { 
      caption: `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

   ⟮ ᴏwɴᴇʀ - ᴍᴇɴᴜ ⟯ 
☾ /addprem <id 5d> ☽
☾ /delprem <id> ☽
☾ /addadmin <id> ☽
☾ /deladmin <id> ☽`, 
      reply_markup: {
        inline_keyboard: [
          [{ text: "📞 𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/NPCmodeSad" }],
          [{ text: "📌 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯", url: "https://t.me/" }]
        ]
      }
    });
  } else if (data === "thanksto") {
    bot.sendVideo(chatId, "https://files.catbox.moe/gcouxh.mp4", { 
      caption: `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する

     ᴛʜᴀɴᴋs ᴛᴏᴏ 
⌗ NPC VILLAIN ☾ 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 ☽
⌗ VINO ☾ 𝙾𝙻𝙳 𝙵𝚁𝙸𝙴𝙽𝙳 ☽
⌗ RUAN ☾ 𝙱𝚎𝚜𝚝𝙵𝚛𝚒𝚎𝚗𝚍 ☽
⌗ ARI ☾ 𝙱𝚎𝚜𝚝𝙵𝚛𝚒𝚎𝚗𝚍☽
⌗ RAPI ☾ 𝙱𝚎𝚜𝚝𝙵𝚛𝚒𝚎𝚗𝚍 ☽
⌗ 𝚃𝙷𝙰𝙽𝙺𝚂 𝙰𝙻𝙻 😚
`,
      reply_markup: {
        inline_keyboard: [
          [{ text: "📞 𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/NPCmodeSad" }],
          [{ text: "📌 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯", url: "https://t.me/" }]
        ]
      }
    });
  } else if (data === "controlmenu") {
 bot.sendVideo(chatId, "https://files.catbox.moe/gcouxh.mp4", { 
      caption: `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

    ⟮ sᴇᴛᴛɪɴɢ ᴍᴇɴᴜ ⟯
infokan function buat ini ^_^
`,
      reply_markup: {
        inline_keyboard: [
          [{ text: "📞 𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/NPCmodeSad" }],
          [{ text: "📌 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯", url: "https://t.me/" }]
        ]
      }
    });
  }

  bot.answerCallbackQuery(query.id);
});


bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  
  if (bugRequests[chatId] && bugRequests[chatId].stage === "awaitingNumber") {
    const targetNumber = msg.text.trim();
    const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    const options = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "TornadoBlast", callback_data: `vxthunder:${jid}` },
            { text: "X-Tornado", callback_data: `vxthunderblast:${jid}` }
          ],
          [
            { text: "TornadoInvis", callback_data: `vxexecutive:${jid}` },
            { text: "TornadoBug", callback_data: `vxtravaz:${jid}` }
          ],
          [
            { text: "Xcrash", callback_data: `vxtravaz:${jid}` },
            { text: "TravasZap", callback_data: `xvxeroblast:${jid}` }
          ],
          [
            { text: "TornadoIphone", callback_data: `vxgalaxite:${jid}` },
            { text: "TornadoUi", callback_data: `vxtravaz:${jid}` }
          ]
        ]
      }
    };


    bot.sendVideo(chatId, "https://files.catbox.moe/owm8ms.mp4", {
      caption: `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

     [ ᴛᴀʀɢᴇᴛ ᴛᴇʀᴋᴜɴᴄɪ 🔒 ]
 👤 ᴛᴀʀɢᴇᴛ : ${formattedNumber}

❗sᴇʟʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ ʙᴇʟᴏw ғᴏʀ sᴇɴᴅɪɴɢ ʙᴜɢ
`,
            parse_mode: "Markdown",
            ...options
        });

    delete bugRequests[chatId];
  }
});


bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const [action, jid] = callbackQuery.data.split(":");

  // Cek apakah tombol berasal dari menu bug
  if (action.startsWith('vx')) {
    try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addsender 62xxx"
      );
    }
    
      await bot.editMessageReplyMarkup(
        { inline_keyboard: [[{ text: "Sedang Proses 🔄...", callback_data: "processing" }]] },
        { chat_id: chatId, message_id: messageId }
      );

      let bugType;


      if (action === "vxthunder") {
        await comboxx1(sessions.values().next().value, jid);
        bugType = "Galaxite Stronger";
      } else if (action === "vxthunderblast") {
        await thunder(sessions.values().next().value, jid);
        bugType = "Galaxite Stronger";
      } else if (action === "vxexecutive") {
        await comboxx1(sessions.values().next().value, jid);        
        bugType = "Travas De Loca";
      } else if (action === "vxtravaz") {
        await comboxx2(sessions.values().next().value, jid);
        bugType = "Travas De Loca";
      } else if (action === "xvxeroblast") {
        await thunder(sessions.values().next().value, jid);
        bugType = "Galaxite Stronger";
      } else if (action === "vxgalaxite") {
        await executive(sessions.values().next().value, jid);
        bugType = "Technique";
      } else if (action === "vxtravaz") {
        await executive(sessions.values().next().value, jid); 
        bugType = "Foring Extansion";
      } else {
        return bot.sendMessage(chatId, "❌ Unknown action.");
      }

      // Kirim pesan sukses
      bot.sendPhoto(chatId, "https://files.catbox.moe/mh63zy.jpg", {

    caption: `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

 ⟮ 𝙎𝙪𝙘𝙘𝙚𝙨 𝙎𝙚𝙣𝙙𝙞𝙣𝙜 𝘽𝙪𝙜❗ ⟯
▣ ᴛᴀʀɢᴇᴛ : ${jid}
▣ ᴛʏᴘᴇ : ${bugType}
`,

    parse_mode: "Markdown",

    reply_markup: {

        inline_keyboard: [

            [{ text: "📞 𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/NPCmodeSad" }],

            [{ text: "📌 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯", url: "https://t.me/" }]

        ]

    }
});
      

      // Hapus tombol setelah berhasil dikirim
      await bot.editMessageReplyMarkup(
        { inline_keyboard: [] },
        { chat_id: chatId, message_id: messageId }
      );

      // Tunggu sesuai jeda yang telah diatur
    } catch (error) {
      bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
    }
  }
});

/// AREA bot.onText




bot.onText(/\/addsender (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
  return bot.sendMessage(
    chatId,
    "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
    { parse_mode: "Markdown" }
  );
}
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});



const moment = require('moment');


bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ You are not authorized to add premium users.");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID and duration. Example: /addprem 6843967527 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Missing input. Please specify a duration. Example: /addprem 6843967527 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number. Example: /addprem 6843967527 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ Invalid duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} added ${userId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ User ${userId} has been added to the premium list until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});


//=====================================
bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addadmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addadmin 6843967527.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${userId} To Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
    }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Please provide a user ID. Example: /delprem 6843967527");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ User ${userId} is not in the premium list.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ User ${userId} has been removed from the premium list.`);
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
    if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
            { parse_mode: "Markdown" }
        );
    }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /deladmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /deladmin 6843967527.");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been removed from admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
    }
});

console.log("Bot Berhasil Di Pakai...");