module.exports = {
  BOT_TOKEN: "8151155511:AAFGIC8w9WazrRigcLhi9mUPH1ciLwPDTew",
      OWNER_ID: ["6614718105"],
};