module.exports = {
  BOT_TOKEN: "Tolen",
  OWNER_ID: ["6484803509"],
};

// PASTIIN TOKEN DAH TERDAFTAR DI DATA BASE