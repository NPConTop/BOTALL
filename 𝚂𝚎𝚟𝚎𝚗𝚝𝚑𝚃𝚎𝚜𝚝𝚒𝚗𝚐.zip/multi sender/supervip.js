const supervipUsers = [
  "7112830272"
];

module.exports = supervipUsers;