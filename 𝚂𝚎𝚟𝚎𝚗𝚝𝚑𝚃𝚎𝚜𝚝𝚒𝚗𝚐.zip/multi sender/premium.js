const premiumUsers = [
  '7112830272' 
];

module.exports = premiumUsers;