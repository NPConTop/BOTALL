// BOT TELE
module.exports = {
  BOT_TOKEN: "8151155511:AAFGIC8w9WazrRigcLhi9mUPH1ciLwPDTew", // Token bot Telegram
  OWNER_ID: "6614718105", // ID pemilik bot
  allowedGroupIds: [-1002829714785], // ID grup yang diizinkan
};