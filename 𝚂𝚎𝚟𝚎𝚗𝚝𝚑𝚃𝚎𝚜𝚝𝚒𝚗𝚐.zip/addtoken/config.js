// BOT TELE
module.exports = {
  BOT_TOKEN: "8099344658:AAEhqpTExyBrZCBtrmBwLiaoEPoCGnMnu3g", // Token bot Telegram
  OWNER_ID: "8190878548",
  allowedGroupIds: [-1002401306074, -1002361556670], // ID grup yang diizinkan
};