// function/waSession.js
const fs = require("fs");
const path = require("path");
const P = require("pino");
const { useMultiFileAuthState, makeWASocket, DisconnectReason } = require("@whiskeysockets/baileys");

const sessions = new Map();
const SESSIONS_FILE = "./sessions.json";
const SESSIONS_DIR = "./sessions";

// Simpan session aktif
function saveActiveSessions(botNumber) {
  try {
    let saved = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      saved = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!saved.includes(botNumber)) {
        saved.push(botNumber);
      }
    } else {
      saved.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(saved));
  } catch (error) {
    console.error("❌ Error saving session:", error);
  }
}

// Buat direktori session
function createSessionDir(botNumber) {
  const dir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

// Inisialisasi semua koneksi aktif
async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`📲 Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`🔌 Menghubungkan bot: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`✅ Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`🔄 Reconnect bot: ${botNumber}`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("🔴 Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("❗ Error initializing WA connections:", error);
  }
}

// Koneksi satu per satu (buat pairing / command connect)
async function connectToWhatsApp(bot, botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber}
╰➤ Status : Loading...\`\`\``,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber}
╰➤ Status : Connected ✅\`\`\``,
        { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
      );
    } else if (connection === "connecting") {
      try {
        await new Promise((res) => setTimeout(res, 1000));
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formatted = code.match(/.{1,4}/g)?.join("-") || code;

          await bot.editMessageText(
            `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber}
╰➤ Status : Pairing
╰➤ Code   : ${formatted}\`\`\``,
            { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
          );
        }
      } catch (err) {
        console.error("❗ Error pairing:", err);
        await bot.editMessageText(
          `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber}
╰➤ Status : Error
╰➤ Pesan  : ${err.message}\`\`\``,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );
      }
    } else if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500) {
        await bot.editMessageText(
          `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber}
╰➤ Status : Reconnecting...🔁\`\`\``,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );
        await connectToWhatsApp(bot, botNumber, chatId);
      } else {
        await bot.editMessageText(
          `\`\`\`Статус кода сопряжения здесь
╰➤ Number  : ${botNumber}
╰➤ Status : Gagal Tersambung ❌\`\`\``,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );
        fs.rmSync(sessionDir, { recursive: true, force: true });
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
  return sock;
}

// Export semua fungsi
module.exports = {
  connectToWhatsApp,
  initializeWhatsAppConnections,
  sessions,
  saveActiveSessions
};