module.exports = {
  BOT_TOKEN: "8151155511:AAEhiqcXIVyvKaQsr1HYEXrgasGcPxUkQjY",
  OWNER_ID: ["6614718105"],
};