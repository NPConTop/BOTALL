// config.js
//Credit Sarah-Xhin @CryCodexx - @XhinRb
module.exports = {
    BOT_TOKEN: "8143907627:AAGPtvj4klyn2emj6EXUva1W47rzU7FokDY", 
    ADMIN_ID: '6614718105'
};